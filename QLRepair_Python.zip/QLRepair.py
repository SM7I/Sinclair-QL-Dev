#!/usr/bin/env python3

"""
QLRepair v1.2

(c)2026 SM7I Projects

Recover QDOS executable metadata from XTcc records and
create a QDOS-aware ZIP archive compatible with QLZIP.
"""

import argparse
import struct
import sys
import time
import zipfile
from pathlib import Path

#
# QDOS constants
#

SHORTID = 0x4AFB
LONGID = b"QDOS02"

MAX_NAME = 36

MIN_DATASPACE = 1
MAX_DATASPACE = 16 * 1024 * 1024


#
# Helpers
#

def be16(value):
    return struct.pack(">H", value)


def be32(value):
    return struct.pack(">I", value)


def qdos_time():
    """
    QDOS epoch starts 1-Jan-1961.

    QLZIP uses:
        Unix time + 283996800
    """
    return int(time.time()) + 283996800


#
# XTcc handling
#

def find_xtcc(data):
    """
    Search whole file backwards.

    Returns:
        (offset, dataspace)

    or:
        None
    """

    candidates = []

    for pos in range(len(data) - 8, -1, -1):

        if data[pos:pos + 4] != b"XTcc":
            continue

        try:
            dataspace = struct.unpack(
                ">I",
                data[pos + 4:pos + 8]
            )[0]

        except Exception:
            continue

        if (
            MIN_DATASPACE
            <= dataspace
            <= MAX_DATASPACE
        ):
            candidates.append(
                (pos, dataspace)
            )

    if not candidates:
        return None

    return candidates[0]


def dump_xtcc(data, offset):

    start = max(0, offset - 16)
    end = min(len(data), offset + 24)

    print()
    print("Bytes around XTcc")
    print("-----------------")
    print(data[start:end].hex(" "))
    print()


#
# QDOS structures
#

def build_qdirect(
    filename,
    filesize,
    dataspace
):
    """
    Build the 64-byte qdirect structure.
    """

    shortname = filename[:MAX_NAME]

    hdr = bytearray()

    #
    # d_length
    #

    hdr += be32(filesize)

    #
    # d_access
    #

    hdr += b"\x00"

    #
    # d_type = executable
    #

    hdr += b"\x01"

    #
    # d_datalen = dataspace
    #

    hdr += be32(dataspace)

    #
    # d_reserved
    #

    hdr += be32(0)

    #
    # d_szname
    #

    hdr += be16(len(shortname))

    #
    # d_name[36]
    #

    hdr += (
        shortname.encode(
            "ascii",
            errors="replace"
        )
        .ljust(MAX_NAME, b"\x00")
    )

    now = qdos_time()

    #
    # d_update
    #

    hdr += be32(now)

    #
    # d_refdate
    #

    hdr += be32(0)

    #
    # d_backup
    #

    hdr += be32(0)

    if len(hdr) != 64:
        raise RuntimeError(
            f"qdirect size incorrect: "
            f"{len(hdr)}"
        )

    return bytes(hdr)


def build_qdosextra(
    filename,
    filesize,
    dataspace
):
    """
    Build QDOS02 ZIP extra field.

    Layout:

        4A FB
        48 00
        QDOS02...
        qdirect

    Total = 76 bytes
    """

    qdirect = build_qdirect(
        filename,
        filesize,
        dataspace
    )

    payload = (
        LONGID.ljust(8, b"\x00")
        + qdirect
    )

    extra = bytearray()

    #
    # IMPORTANT
    #
    # Match QLZIP exactly.
    #
    # QLZIP stores:
    #
    #     4A FB
    #
    # not:
    #
    #     FB 4A
    #

    extra += struct.pack(
        ">H",
        SHORTID
    )

    #
    # payload length
    #
    # 72 bytes => 48 00
    #

    extra += struct.pack(
        "<H",
        len(payload)
    )

    extra += payload

    return bytes(extra)


#
# Analysis
#

def analyse(filename):

    path = Path(filename)

    if not path.exists():

        print()
        print(
            f"ERROR: file not found:\n"
            f"    {filename}"
        )
        print()

        return None, None

    if not path.is_file():

        print()
        print(
            f"ERROR: not a regular file:\n"
            f"    {filename}"
        )
        print()

        return None, None

    data = path.read_bytes()

    xtcc = find_xtcc(data)

    print()
    print("QRepair Analysis")
    print("----------------")
    print(
        f"File size        : {len(data)}"
    )

    if xtcc:

        offset, dataspace = xtcc

        print(
            "XTcc             : found"
        )

        print(
            f"Offset           : 0x{offset:X}"
        )

        print(
            f"Dataspace        : {dataspace}"
        )

        print(
            f"Dataspace (hex)  : 0x{dataspace:X}"
        )

        distance = (
            len(data)
            - (offset + 8)
        )

        print(
            f"Bytes after XTcc : "
            f"{distance}"
        )

        if dataspace < 32:

            print(
                "WARNING: very small "
                "dataspace"
            )

        if dataspace > 1024 * 1024:

            print(
                "WARNING: very large "
                "dataspace"
            )

        dump_xtcc(
            data,
            offset
        )

    else:

        print(
            "XTcc             : not found"
        )

    return data, xtcc


#
# ZIP creation
#

def create_archive(
    infile,
    outfile,
    dataspace
):

    src = Path(infile)

    data = src.read_bytes()

    extra = build_qdosextra(
        src.name,
        len(data),
        dataspace
    )

    info = zipfile.ZipInfo(
        src.name
    )

    info.extra = extra

    info.compress_type = (
        zipfile.ZIP_DEFLATED
    )

    with zipfile.ZipFile(
        outfile,
        "w",
        compression=zipfile.ZIP_DEFLATED
    ) as zf:

        zf.writestr(
            info,
            data
        )

    #
    # Verify
    #

    with zipfile.ZipFile(
        outfile,
        "r"
    ) as zf:

        zi = zf.infolist()[0]

        print()
        print(
            "Archive Verification"
        )
        print(
            "--------------------"
        )

        print(
            f"Stored file  : "
            f"{zi.filename}"
        )

        print(
            f"Original size: "
            f"{zi.file_size}"
        )

        print(
            f"Compressed   : "
            f"{zi.compress_size}"
        )

        print(
            f"Extra bytes  : "
            f"{len(zi.extra)}"
        )

        print(
            f"Header bytes : "
            f"{zi.extra[:8].hex()}"
        )


#
# Main
#

def main():

    parser = argparse.ArgumentParser(
        description="QRepair"
    )

    parser.add_argument(
        "file",
        help="Input executable"
    )

    parser.add_argument(
        "--info",
        action="store_true",
        help="Analyse only"
    )

    parser.add_argument(
        "--dataspace",
        type=int,
        help="Manual dataspace"
    )

    parser.add_argument(
        "--output",
        help="Output ZIP file"
    )

    args = parser.parse_args()

    data, xtcc = analyse(
        args.file
    )

    if data is None:
        sys.exit(1)

    if args.info:
        sys.exit(0)

    if args.dataspace:

        dataspace = args.dataspace

        print()
        print(
            f"Using manual dataspace: "
            f"{dataspace}"
        )

    elif xtcc:

        dataspace = xtcc[1]

        print()
        print(
            f"Using XTcc dataspace: "
            f"{dataspace}"
        )

    else:

        print()
        print(
            "ERROR: No XTcc found.\n"
            "Specify --dataspace."
        )
        print()

        sys.exit(1)

    source = Path(args.file)

    if args.output:

        outfile = args.output

    else:

        outfile = (
            source.stem +
            ".zip"
        )

    try:

        create_archive(
            source,
            outfile,
            dataspace
        )

    except Exception as exc:

        print()
        print(
            f"ERROR creating archive:\n"
            f"{exc}"
        )
        print()

        sys.exit(1)

    print()
    print("Archive Created")
    print("---------------")
    print(f"Input      : {source}")
    print(f"Output     : {outfile}")
    print(f"Dataspace  : {dataspace}")
    print()


if __name__ == "__main__":
    main()