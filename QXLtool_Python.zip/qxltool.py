#!/usr/bin/env python3
"""
qxltool.py - access Sinclair QL QXL.WIN files from a native operating system.

QXLtool 1.14 by Jonathan R. Hudson (c) 1998-2000, GPL v2+,
following the maintained fork https://github.com/xXorAa/qxltool (64-bit fixes,
format-size fix, `unzip`).
Format notes   : QXL.WIN = "QLWA" header + big-endian cluster map + QDOS
                 directories whose hierarchy is encoded in '_'-joined names.

Python port by SM7I Projects 2026

Usage:  qxltool.py [-W] [-w] [-c command] [QXL_FILE] [size_in_MB label ...]

  QXL_FILE   defaults to $QXL_FILE, then C:\\QXL.WIN (Windows) or /dos/QXL.WIN
  -w         open read-write (the default is read-only, to protect your data)
  -W         as -w, and allow an existing file to be (re)formatted
  -c cmd     run a single command and exit (may be repeated)
  file size label...   create and format a new QXL.WIN of `size` MB

Without -c, an interactive prompt accepts the commands listed by `help`:
  info ls lslr dump pwd cd cat cp tcat tcp wr twr unzip mkdir rm rmdir
  init format open close RO RW clone shell version help quit exit
Output of a command may be redirected:  > file   >> file   | program

BACK UP YOUR QXL.WIN BEFORE USING -w.  Do not use it while QPC/QXL has it open.

Differences from the C tool: QDOS names are matched case-insensitively, '/' may
be used instead of '_' in QXL paths, quoted arguments work, file times are
local wall-clock (host mtime), and the end-of-output marker is only printed
for stdin-driven sessions, not with -c.
"""

import datetime
import getopt
import os
import random
import re
import struct
import subprocess
import sys
import zipfile
from zlib import error as zlib_error

VERSION = "1.14-py"
TARGET = "WIN32" if sys.platform == "win32" else ("Linux" if sys.platform.startswith("linux") else sys.platform)
DEFQXL = "C:\\QXL.WIN" if sys.platform == "win32" else "/dos/QXL.WIN"
CLONE_SEP = ";" if sys.platform == "win32" else ":"

ESIZE = 64               # size of a directory entry (and of the file header)
QLPATH_MAX = 36          # longest QDOS file name
T_DIR = 0xFF             # file type of a directory
QL_EPOCH = datetime.datetime(1961, 1, 1)


class QXLError(Exception):
    """A user-facing error."""


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def ql_to_datetime(secs):
    try:
        return QL_EPOCH + datetime.timedelta(seconds=secs)
    except OverflowError:
        return QL_EPOCH


def datetime_to_ql(dt):
    return max(0, min(0xFFFFFFFF, int((dt - QL_EPOCH).total_seconds())))


def file_ql_time(path):
    """Local wall-clock modification time of a host file, in QL seconds."""
    try:
        return datetime_to_ql(datetime.datetime.fromtimestamp(os.stat(path).st_mtime))
    except (OSError, OverflowError, ValueError):
        return datetime_to_ql(datetime.datetime.now())


def qname(text):
    """Normalise a user-supplied QXL name: '/' and '\\' mean '_'."""
    return text.replace("/", "_").replace("\\", "_")


# --------------------------------------------------------------------------
# on-disk structures
# --------------------------------------------------------------------------

class Entry:
    """A 64-byte QDOS directory entry."""
    FMT = struct.Struct(">IHIIH36sIHHI")
    assert FMT.size == ESIZE
    __slots__ = ("length", "type", "data", "d1", "nlen", "nameb", "date", "d2", "map", "d3")

    def __init__(self, length=0, type=0, data=0, d1=0, nlen=0, nameb=b"", date=0, d2=0, map=0, d3=0):
        self.length, self.type, self.data, self.d1 = length, type, data, d1
        self.nlen, self.nameb, self.date = nlen, nameb, date
        self.d2, self.map, self.d3 = d2, map, d3

    @classmethod
    def parse(cls, raw):
        return cls(*cls.FMT.unpack(bytes(raw)))

    def pack(self):
        return self.FMT.pack(self.length, self.type, self.data, self.d1, self.nlen,
                             self.nameb[:QLPATH_MAX].ljust(QLPATH_MAX, b"\0"),
                             self.date, self.d2, self.map, self.d3)

    @classmethod
    def make(cls, name, length, type_, data, date, first):
        nb = name.encode("latin-1", "replace")[:QLPATH_MAX]
        return cls(length, type_, data, 0, len(nb), nb, date, 0, first, 0)

    @property
    def name(self):
        return self.nameb[:min(self.nlen, QLPATH_MAX)].decode("latin-1")

    @property
    def is_dir(self):
        return self.type == T_DIR

    @property
    def size(self):
        """Data size (the on-disk length includes the 64 byte header)."""
        return self.length - ESIZE


class Dir:
    """A directory file, loaded into memory.  Slot 0 is the (unused) header."""

    def __init__(self, qxl, name, first, length, parent=None, index=0):
        length = min(length, qxl.total * qxl.sectc)      # guard against corrupt lengths
        self.qxl, self.name, self.first, self.length = qxl, name, first, length
        self.parent, self.index = parent, index
        self.raw = bytearray(qxl.read_chain(first, length))

    @property
    def nslots(self):
        return len(self.raw) // ESIZE

    def entry(self, i):
        return Entry.parse(self.raw[i * ESIZE:(i + 1) * ESIZE])

    def set_entry(self, i, e):
        self.raw[i * ESIZE:(i + 1) * ESIZE] = e.pack()

    def flush(self):
        """Write the directory back, allocating clusters if it grew."""
        before = self.qxl.free
        first = self.qxl.write_chain(self.first, bytes(self.raw))
        if self.qxl.free != before:                 # clusters were taken: record it (as the original does)
            self.qxl.write_header()
        if first != self.first:             # a directory that had no cluster yet
            self.first = first
            if self.parent is None:
                self.qxl.direct = first
            else:
                e = self.parent.entry(self.index)
                e.map = first
                self.parent.set_entry(self.index, e)
                self.parent.flush()


class QXL:
    """An open QXL.WIN file."""
    HDR = struct.Struct(">4sH20sHHHHH6sHHHHHHI6s")
    assert HDR.size == 64

    def __init__(self, path, rw=False):
        self.path, self.rw = path, rw
        try:
            self.f = open(path, "r+b" if rw else "rb")
        except OSError as e:
            raise QXLError("%s: %s" % (path, e.strerror))
        try:
            self._read_header()
        except Exception:
            self.f.close()
            raise

    # -- header -------------------------------------------------------------
    def _read_header(self):
        self.f.seek(0)
        raw = self.f.read(64)
        if len(raw) < 64 or raw[:4] != b"QLWA":
            raise QXLError("Not a QXL file")
        (_id, self.namlen, name, self.d0, self.rand, self.access, self.d1, sectc, self.d2,
         self.total, self.free, self.formatted, self.d3, self.first, self.direct,
         self.dlen, self.d4) = self.HDR.unpack(raw)
        self.sectc = sectc * 512
        if self.sectc == 0 or self.total == 0:
            raise QXLError("Not a QXL file (bad header)")
        self.label = name.replace(b"\0", b" ").rstrip(b" \0").decode("latin-1")
        self.f.seek(0x40)
        self.map = bytearray(self.f.read(self.total * 2).ljust(self.total * 2, b"\0"))

    def write_header(self):
        self.access = (self.access + 1) & 0xFFFF
        nm = self.label.encode("latin-1", "replace")[:20].ljust(20, b" ")
        self.f.seek(0)
        self.f.write(self.HDR.pack(b"QLWA", self.namlen, nm, self.d0, self.rand, self.access,
                                   self.d1, self.sectc // 512, self.d2, self.total, self.free,
                                   self.formatted, self.d3, self.first, self.direct,
                                   self.dlen, self.d4))
        self.f.flush()

    def close(self):
        self.f.close()

    def require_rw(self):
        if not self.rw:
            raise QXLError("read only filesystem")

    # -- cluster map ---------------------------------------------------------
    def get_map(self, c):
        if c >= self.total:
            raise QXLError("Corrupt QXL file: cluster pointer %d out of range" % c)
        return struct.unpack_from(">H", self.map, c * 2)[0]

    def set_map(self, c, v):
        struct.pack_into(">H", self.map, c * 2, v)
        self.f.seek(0x40 + c * 2)
        self.f.write(struct.pack(">H", v))

    def alloc(self, prev):
        """Take the first free cluster, linking it after `prev` (if any)."""
        if self.free == 0 or self.first == 0:
            raise QXLError("Disk is full!")
        n = self.first
        nxt = self.get_map(n)
        self.free -= 1
        if prev:
            self.set_map(prev, n)
        self.set_map(n, 0)
        self.first = nxt
        return n

    def chain(self, first):
        seen, c = set(), first
        while c:
            if c in seen:
                raise QXLError("Corrupt QXL file: cluster loop")
            seen.add(c)
            yield c
            c = self.get_map(c)

    def free_chain(self, first):
        for c in list(self.chain(first)):
            self.set_map(c, self.first)
            self.first = c
            self.free += 1

    def read_chain(self, first, length):
        out = bytearray()
        for c in self.chain(first):
            if len(out) >= length:
                break
            n = min(length - len(out), self.sectc)
            self.f.seek(c * self.sectc)
            out += self.f.read(n).ljust(n, b"\0")
        return bytes(out.ljust(length, b"\0"))

    def write_chain(self, first, data):
        """Write `data` along the chain starting at `first`; returns the first cluster."""
        c = first or self.alloc(0)
        start, pos = c, 0
        while True:
            n = min(len(data) - pos, self.sectc)
            self.f.seek(c * self.sectc)
            self.f.write(data[pos:pos + n])
            pos += n
            if pos >= len(data):
                break
            nxt = self.get_map(c)
            c = nxt or self.alloc(c)
        return start

    # -- directories ---------------------------------------------------------
    def root_dir(self):
        return Dir(self, "", self.direct, self.dlen)

    def child_dir(self, parent, idx, e):
        return Dir(self, e.name, e.map, e.length, parent, idx)

    def walk(self, d, recurse=True, _seen=None):
        """Yield (dir, index, entry) for the entries of `d`, descending into subdirectories."""
        seen = _seen if _seen is not None else {d.first}
        for i in range(1, d.nslots):
            e = d.entry(i)
            yield d, i, e
            if recurse and e.is_dir and e.map and e.map not in seen:
                seen.add(e.map)
                yield from self.walk(self.child_dir(d, i, e), True, seen)

    def find(self, name, want=0, start=None):
        """Look a full flat name up (exact first, then ignoring case).  -> (dir, idx, entry) | None"""
        low, ci = name.casefold(), None
        for d, i, e in self.walk(start or self.root_dir()):
            if not e.nlen or (want and e.type != want):
                continue
            n = e.name
            if n == name:
                return d, i, e
            if ci is None and n.casefold() == low:
                ci = (d, i, e)
        return ci

    def best_dir(self, name):
        """The deepest existing directory that `name` lives in (the root if none)."""
        best, low = None, name.casefold()
        for d, i, e in self.walk(self.root_dir()):
            if e.is_dir and e.nlen and (best is None or e.nlen > best[2].nlen):
                n = e.name
                if len(name) > len(n) and low.startswith(n.casefold()) and name[len(n)] == "_":
                    best = (d, i, e)
        if best is None:
            return self.root_dir()
        return self.child_dir(*best)

    def list_dir(self, d):
        return [(i, d.entry(i)) for i in range(1, d.nslots) if d.entry(i).length >= ESIZE]

    # -- file operations -----------------------------------------------------
    def read_file(self, e):
        """The data of a file, without its 64 byte header."""
        if not e.map or e.length <= ESIZE:
            return b""
        return self.read_chain(e.map, e.length)[ESIZE:]

    def _new_entry(self, full, data, date, dataspace, is_dir):
        d = self.best_dir(full)
        if d.name:                                   # keep the directory's own spelling
            full = d.name + full[len(d.name):]
        if len(full) > QLPATH_MAX:
            print("Warning: name %r truncated to %d characters" % (full, QLPATH_MAX), file=sys.stderr)
            full = full[:QLPATH_MAX]
        # find a free slot, or grow the directory by one
        slot, grew = None, False
        for i in range(1, d.nslots):
            e = d.entry(i)
            if e.length < ESIZE and e.type != T_DIR:
                slot = i
                break
        if slot is None:
            slot, grew = d.length // ESIZE, True
            d.raw.extend(bytes(max(0, (slot + 1) * ESIZE - len(d.raw))))
            d.length += ESIZE
        # the file's clusters (its first 64 bytes are the unused header)
        first = 0
        if is_dir:
            first = self.alloc(0)
            self.f.seek(first * self.sectc)
            self.f.write(bytes(self.sectc))
            length = ESIZE
        else:
            if data:                                   # (an empty file owns no clusters)
                blob, prev = bytes(ESIZE) + data, 0
                for pos in range(0, len(blob), self.sectc):
                    prev = self.alloc(prev)
                    first = first or prev
                    self.f.seek(prev * self.sectc)
                    self.f.write(blob[pos:pos + self.sectc])
            length = len(data) + ESIZE
        d.set_entry(slot, Entry.make(full, length, T_DIR if is_dir else (1 if dataspace else 0),
                                     dataspace, date, first))
        d.flush()
        if grew:                                     # the directory's own length lives in its parent
            if d.parent is None:
                self.dlen = d.length
            else:
                pe = d.parent.entry(d.index)
                pe.length = d.length
                d.parent.set_entry(d.index, pe)
                d.parent.flush()
        self.write_header()
        return full

    def put(self, full, data, date, dataspace=0):
        """Store a file under its full flat name, replacing any existing one."""
        self.require_rw()
        full = qname(full)
        if not full:
            raise QXLError("Empty file name")
        old = self.find(full)
        reclaim = 0
        if old:
            if old[2].is_dir:
                raise QXLError('Can\'t overwrite directory "%s"' % full)
            reclaim = len(list(self.chain(old[2].map)))
        need = -(-(len(data) + ESIZE) // self.sectc) if data else 0
        if need + 1 > self.free + reclaim:
            raise QXLError("%s %d No room (%d free sectors, %d b wanted %d)" %
                           (full, self.sectc, self.free, len(data) + ESIZE, need))
        if old:
            self._remove(*old)
        return self._new_entry(full, data, date, dataspace, False)

    def mkdir(self, full):
        self.require_rw()
        full = qname(full).rstrip("_")
        if not full:
            raise QXLError("Empty directory name")
        clash = self.find(full)
        if not clash:
            low = (full + "_").casefold()
            for _d, _i, e in self.walk(self.root_dir()):
                if e.nlen and e.name.casefold().startswith(low):
                    clash = (_d, _i, e)
                    break
        if clash:
            raise QXLError("Cannot mkdir for %s as %s exists" % (full, clash[2].name))
        if self.free < 2:
            raise QXLError("Disk is full!")
        return self._new_entry(full, b"", 0, 0, True)

    def _remove(self, d, idx, e):
        if e.map:
            self.free_chain(e.map)
        d.set_entry(idx, Entry())
        d.flush()
        self.write_header()

    def remove(self, full):
        self.require_rw()
        found = self.find(qname(full))
        if not found:
            raise QXLError("Not found")
        if found[2].is_dir:
            raise QXLError("Use rmdir to delete empty directories")
        self._remove(*found)

    def rmdir(self, full):
        self.require_rw()
        found = self.find(qname(full).rstrip("_"), T_DIR)
        if not found:
            raise QXLError("Not found")
        d, idx, e = found
        n = sum(1 for _, x in self.list_dir(self.child_dir(d, idx, e)) if x.nlen)
        if n:
            raise QXLError("Directory must be empty to delete (%d)" % n)
        self._remove(d, idx, e)

    # -- formatting -----------------------------------------------------------
    @staticmethod
    def _format(f, label, bs, total, zero_fill):
        """Write a fresh QXL.WIN structure to the open file `f`."""
        label = label.encode("latin-1", "replace")[:20]
        ns = (total * 2 + bs - 1) // bs + 1          # clusters taken by header + map
        cmap = bytearray(total * 2)

        def setm(c, v):
            struct.pack_into(">H", cmap, c * 2, v)

        for c in range(0, ns - 1):                    # header/map clusters are chained 0 -> 1 -> ...
            setm(c, c + 1)
        setm(ns - 1, 0)
        direct, first = ns, ns + 1                    # root directory cluster, first free cluster
        setm(direct, 0)
        for c in range(first, total - 1):
            setm(c, c + 1)
        setm(total - 1, 0)
        hdr = QXL.HDR.pack(b"QLWA", len(label), label.ljust(20, b" "), 0, random.randrange(65536),
                           1, 0, bs // 512, bytes(6), total, total - ns - 1,
                           (total * 2 + 511 + 0x40) // 512, 1, first, direct, ESIZE, bytes(6))
        f.seek(0)
        f.write(hdr)
        f.seek(0x40)
        f.write(cmap)
        if zero_fill:
            f.seek(direct * bs)
            left, chunk = (total - direct) * bs, bytes(1 << 20)
            while left > 0:
                f.write(chunk[:left])
                left -= len(chunk)
        f.flush()

    @classmethod
    def create(cls, path, size_mb, label, overwrite=False):
        """Create (and format) a new QXL.WIN of `size_mb` megabytes."""
        req = int(size_mb)
        ss = max(1, min(256, req))
        if ss != req:
            print("Size must be 1 to 256 Mb, using %d Mb" % ss, file=sys.stderr)
        bs = 512 << next(i for i, lim in enumerate((32, 64, 128, 256)) if ss <= lim)
        total = min((ss << 20) // bs, 0xFFFF)         # 16 bit field: drop the last cluster on 32/64/128/256 MB
        existed = os.path.exists(path)
        if existed and not overwrite:
            raise QXLError("New QXL: %s: File exists" % path)
        try:
            with open(path, "r+b" if existed else "w+b") as f:
                f.truncate(ss << 20)
                cls._format(f, label, bs, total, zero_fill=existed)
        except OSError as e:
            raise QXLError("New QXL: %s: %s" % (path, e.strerror))

    def init(self, label):
        """Re-initialise this file (all data is lost), keeping its geometry."""
        self.require_rw()
        self.f.seek(0)
        self._format(self.f, label, self.sectc, self.total, True)
        self._read_header()


# --------------------------------------------------------------------------
# output plumbing (redirection)
# --------------------------------------------------------------------------

class Out:
    """Where a command's output goes: stdout, a file, or a pipe."""

    def __init__(self, stream, closer=None, is_file=False, text=False):
        self.stream, self.closer, self.is_file, self.text_mode = stream, closer, is_file, text
        self.encoding = (getattr(sys.stdout, "encoding", None) or "utf-8") if stream is sys.stdout.buffer else "utf-8"

    def _sync(self):
        if self.stream is sys.stdout.buffer:
            sys.stdout.flush()                        # keep print() and raw writes in order

    def text(self, s):
        self._sync()
        self.stream.write(s.encode(self.encoding, "replace"))

    def data(self, b):
        self._sync()
        if self.text_mode:                            # QDOS LF -> host CR/LF
            b = b.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        self.stream.write(b)

    def close(self):
        try:
            self.stream.flush()
        except (OSError, ValueError):
            pass
        if self.closer:
            self.closer()


def split_args(s):
    """Split on blanks; "double quotes" keep spaces together."""
    return [a[0] or a[1] for a in re.findall(r'"([^"]*)"|(\S+)', s)]


def open_out(line, text_mode):
    """Handle  > file  >> file  | prog  in a command line.  -> (remaining line, Out)"""
    m = re.search(r"[>|]", line)
    stdout = Out(sys.stdout.buffer, text=text_mode)
    if not m:
        return line, stdout
    kind, rest = m.group(0), line[m.end():]
    append = kind == ">" and rest.startswith(">")
    if append:
        rest = rest[1:]
    rest = rest.lstrip(" \t")
    if rest.startswith('"') and '"' in rest[1:]:
        target, tail = rest[1:].split('"', 1)
    else:
        parts = rest.split(None, 1)
        target, tail = (parts[0], parts[1] if len(parts) > 1 else "") if parts else ("", "")
    if kind == "|":
        proc = subprocess.Popen(line[m.end():].strip(), shell=True, stdin=subprocess.PIPE)
        return line[:m.start()], Out(proc.stdin, lambda: (proc.stdin.close(), proc.wait()), False, text_mode)
    remaining = line[:m.start()] + " " + tail
    try:
        fh = open(target, "ab" if append else "wb")
    except OSError as e:
        raise QXLError("%s: %s" % (target, e.strerror))
    return remaining, Out(fh, fh.close, is_file=not append, text=text_mode)


# --------------------------------------------------------------------------
# the command shell
# --------------------------------------------------------------------------

class Shell:
    def __init__(self, qxl, rw_flag, fmode):
        self.qxl, self.rw_flag, self.fmode = qxl, rw_flag, fmode
        self.cwd = ""                                  # full flat name of the current directory
        # (name, handler, text-mode flag, needs-open-file) in the original's order:
        # commands are recognised by prefix, so order matters
        self.table = [
            ("cd", self.c_cd, 0, 1), ("lslr", self.c_lslr, 0, 1), ("ls", self.c_ls, 0, 1),
            ("dump", self.c_dump, 0, 1), ("pwd", self.c_pwd, 0, 1), ("cat", self.c_cp, 0, 1),
            ("cp", self.c_cp, 0, 1), ("tcat", self.c_cp, 1, 1), ("tcp", self.c_cp, 1, 1),
            ("twr", self.c_wr, 1, 1), ("info", self.c_info, 0, 1), ("quit", self.c_quit, 0, 0),
            ("exit", self.c_quit, 0, 0), ("init", self.c_init, 0, 1), ("wr", self.c_wr, 0, 1), ("unzip", self.c_unzip, 0, 1),
            ("rmdir", self.c_rmdir, 0, 1), ("rm", self.c_rm, 0, 1), ("mkdir", self.c_mkdir, 0, 1),
            ("version", self.c_version, 0, 0), ("help", self.c_help, 0, 0), ("open", self.c_open, 0, 0),
            ("close", self.c_close, 0, 1), ("format", self.c_format, 0, 0), ("shell", self.c_shell, 0, 0),
            ("clone", self.c_clone, 0, 1), ("RO", self.c_ro, 0, 1), ("RW", self.c_rw, 0, 1),
        ]
        self.out = None
        self.quit = False
        self.text_cmd = False                          # True while running tcat/tcp/twr

    # -- name helpers --------------------------------------------------------
    def prefix(self):
        return self.cwd + "_" if self.cwd else ""

    def full(self, name):
        """Full flat name of a user-typed name: relative to the cwd unless it starts with '/'."""
        absolute = name[:1] in "/\\" and name != ""
        name = qname(name)
        return name.lstrip("_") if absolute else self.prefix() + name

    def cwd_dir(self):
        if not self.cwd:
            return self.qxl.root_dir()
        found = self.qxl.find(self.cwd, T_DIR)
        if not found:
            self.cwd = ""
            return self.qxl.root_dir()
        return self.qxl.child_dir(*found)

    def shown(self, e):
        n, p = e.name, self.prefix()
        return n[len(p):] if p and n.casefold().startswith(p.casefold()) else n

    # -- running a line ------------------------------------------------------
    def run(self, line):
        line = line.split("#", 1)[0]
        ptr = line.lstrip(" \t")
        if not ptr.strip():
            return
        for name, fn, text, needs_open in self.table:
            if ptr.startswith(name):
                word_end = len(name)
                while word_end < len(ptr) and ptr[word_end] > " ":
                    word_end += 1
                if needs_open and self.qxl is None:
                    print("That requires an open QXL_FILE", file=sys.stderr)
                    return
                self.text_cmd = bool(text)
                try:
                    rest, self.out = open_out(ptr[word_end:], text)
                    args = split_args(rest)
                    try:
                        if fn(args):
                            print("Invalid argument(s)", file=sys.stderr)
                    finally:
                        self.out.close()
                except QXLError as e:
                    print(e, file=sys.stderr)
                except BrokenPipeError:
                    pass
                except OSError as e:
                    print("%s" % e, file=sys.stderr)
                return
        print("Invalid command %s" % ptr.rstrip())

    # -- commands --------------------------------------------------------------
    def c_quit(self, a):
        self.quit = True
        return 0

    def c_version(self, a):
        self.out.text("qxltool %s for %s\n" % (VERSION, TARGET))
        return 0

    def c_help(self, a):
        self.out.text("Commands in qxltool %s\n\n" % VERSION)
        for name, *_ in self.table:
            self.out.text("\t%s\n" % name)
        self.out.text("\nRead the fine manual for more information\n")
        return 0

    def c_pwd(self, a):
        self.out.text("%s\n" % (self.cwd or "/"))
        return 0

    def c_cd(self, a):
        p = a[0] if a else ""
        if p in ("", "/", "_"):
            self.cwd = ""
        elif p == "..":
            if self.cwd:
                found = self.qxl.find(self.cwd, T_DIR)
                self.cwd = found[0].name if found else ""
        elif p != ".":
            p = qname(p).rstrip("_")
            found = self.qxl.find(self.full(p), T_DIR)
            if found:
                self.cwd = found[2].name
            else:
                print("Not found %s" % p, file=sys.stderr)
                return -1
        return 0

    def list_line(self, e, flen):
        n = self.shown(e)
        s = "%-36s %s %8d " % (n, "DELETED" if e.length == 0 else "", flen)
        if e.type != T_DIR:
            s += ql_to_datetime(e.date).strftime("%d-%m-%y %H:%M:%S ")
        else:
            s += "      (Directory) "
        if e.type == 1:
            s += "(%d) " % e.data
        return s + "\n"

    def _ls(self, recurse):
        qx = self.qxl
        for d, i, e in qx.walk(self.cwd_dir(), recurse):
            if e.length - ESIZE >= 0:
                self.out.text(self.list_line(e, e.length - ESIZE))

    def c_ls(self, a):
        if a:
            print("ls[lr] takes no parameters (currently), cd first", file=sys.stderr)
            return 0
        self._ls(False)
        return 0

    def c_lslr(self, a):
        if a:
            print("ls[lr] takes no parameters (currently), cd first", file=sys.stderr)
            return 0
        self._ls(True)
        return 0

    def c_dump(self, a):
        """Raw view of every directory slot below the current directory."""
        def show(d, depth):
            self.out.text("Directory %r: cluster %d, length %d, %d slots\n" %
                          (d.name or "/", d.first, d.length, d.nslots))
            for i in range(1, d.nslots):
                e = d.entry(i)
                flag = "" if (e.length >= ESIZE and e.nlen) else "  <-- unused/inconsistent"
                self.out.text("  [%3d] len=%-8d type=%-3d data=%-6d nlen=%-2d map=%-5d date=%-10d %s%s\n" %
                              (i, e.length, e.type, e.data, e.nlen, e.map, e.date, e.name, flag))
        seen = set()
        stack = [self.cwd_dir()]
        while stack:
            d = stack.pop(0)
            if d.first in seen:
                continue
            seen.add(d.first)
            show(d, 0)
            for i in range(1, d.nslots):
                e = d.entry(i)
                if e.is_dir and e.map:
                    stack.append(self.qxl.child_dir(d, i, e))
        return 0

    def c_cp(self, a):
        if not a:
            return 1
        found = self.qxl.find(self.full(a[0]))
        if not found:
            print("Not found", file=sys.stderr)
            return 0
        e = found[2]
        if e.is_dir:
            print("%s is a directory" % e.name, file=sys.stderr)
            return 0
        self.out.data(self.qxl.read_file(e))
        if e.type == 1 and e.data and self.out.is_file and not self._has_xtcc(e):  # dataspace trailer
            self.out.stream.write(b"XTcc" + struct.pack(">I", e.data))
        return 0

    def _has_xtcc(self, e):
        return self.qxl.read_file(e)[-8:-4] == b"XTcc"

    def c_wr(self, a):
        """wr host_file [qxl_name]   (twr: DOS text, CR/LF -> LF)"""
        if not a:
            return 1
        self.qxl.require_rw()
        src = a[0]
        name = a[1] if len(a) > 1 else os.path.basename(src.replace("\\", "/")).replace(".", "_")
        try:
            with open(src, "rb") as fh:
                data = fh.read()
        except OSError as e:
            print("%s: %s" % (src, e.strerror), file=sys.stderr)
            return 0
        dataspace = 0
        if len(data) >= 8 and data[-8:-4] == b"XTcc":  # data space from the XTcc trailer (which stays, as in qxltool)
            dataspace = struct.unpack(">I", data[-4:])[0]
        if self.text_cmd:
            data = data.replace(b"\r\n", b"\n")
        self.qxl.put(self.full(name), data, file_ql_time(src), dataspace)
        return 0

    # -- unzip -----------------------------------------------------------------
    @staticmethod
    def _qdos_extra(x):
        """(type, dataspace) from a zip extra block's QDOS/SMS field (id 0xfb4a), or None."""
        while len(x) >= 4:
            zid, sz = struct.unpack_from("<HH", x)
            d = x[4:4 + sz]
            if sz > len(x) - 4:
                break
            if zid in (0xFB4A, 0x4AFB):
                off = 4 if d[:4] == b"QZHD" else 8 if d[:4] == b"QDOS" else -1
                if off >= 0 and sz >= off + 10:
                    return d[off + 5], struct.unpack(">I", d[off + 6:off + 10])[0]
            x = x[4 + sz:]
        return None

    @staticmethod
    def _zip_utime(x):
        while len(x) >= 4:
            zid, sz = struct.unpack_from("<HH", x)
            if sz > len(x) - 4:
                break
            if zid == 0x5455 and sz >= 5 and x[4] & 1:
                return struct.unpack_from("<i", x, 5)[0]
            x = x[4 + sz:]
        return None

    def _zip_mkdir(self, name):
        if self.qxl.find(self.full(name), T_DIR):
            return
        self.out.text("  creating: %s\n" % name)
        try:
            self.qxl.mkdir(self.full(name))
        except QXLError as e:
            print(e)

    def _zip_extract(self, zf, zi):
        zname = zi.orig_filename
        isdir = zname.endswith("/")
        pre = len(self.cwd) + 1 if self.cwd else 0
        s = zname.lstrip("/")
        if isdir:
            s = s[:-1]
        qn, seps = [], []
        for ch in s:
            if len(qn) + pre >= QLPATH_MAX:
                print("%s: name too long for QDOS, skipped" % zname, file=sys.stderr)
                return False
            sep = ch in "/\\"
            seps.append(sep)
            qn.append("_" if sep or ch == "." else ch)
        qname = "".join(qn)
        if not qname:
            return True
        for i, sep in enumerate(seps):                 # directories in the path
            if sep:
                self._zip_mkdir(qname[:i])
        if isdir:
            self._zip_mkdir(qname)
            return True
        if zi.flag_bits & 1:
            print("%s: encrypted, skipped" % zname, file=sys.stderr)
            return False
        if zi.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
            print("%s: compression method %d not supported, skipped" % (zname, zi.compress_type), file=sys.stderr)
            return False
        # local header (its extra field may hold the QDOS header, or the timestamp)
        lx = b""
        try:
            zf.fp.seek(zi.header_offset)
            lh = zf.fp.read(30)
            if len(lh) != 30 or struct.unpack_from("<I", lh)[0] != 0x04034B50:
                raise ValueError
            nlen, xlen = struct.unpack_from("<HH", lh, 26)
            zf.fp.seek(nlen, 1)
            lx = zf.fp.read(xlen)
        except (ValueError, OSError, struct.error):
            print("%s: bad local header, skipped" % zname, file=sys.stderr)
            return False
        q = self._qdos_extra(zi.extra) or self._qdos_extra(lx)
        ut = self._zip_utime(zi.extra)
        if ut is None:
            ut = self._zip_utime(lx)
        try:
            if ut is not None:
                ql = datetime_to_ql(datetime.datetime.fromtimestamp(ut))
            else:
                ql = datetime_to_ql(datetime.datetime(*zi.date_time))
        except (ValueError, OverflowError, OSError):
            ql = 0
        try:
            data = zf.read(zi)
        except (zipfile.BadZipFile, zlib_error, RuntimeError, OSError):
            print("%s: bad zip data (CRC or length), skipped" % zname, file=sys.stderr)
            return False
        dspace, how = 0, ""
        if q:                                          # the QDOS header in the zip is definitive
            dspace = q[1] if q[0] == 1 else 0
            how = " (QDOS extra field)"
        elif len(data) >= 8 and data[-8:-4] == b"XTcc":
            dspace = struct.unpack(">I", data[-4:])[0]
            data = data[:-8]                           # the trailer is not part of the file
            how = " (XTcc trailer)"
        try:
            self.qxl.put(self.full(qname), data, ql, dspace)
        except QXLError as e:
            print(e, file=sys.stderr)
            return False
        self.out.text("  %s: %s -> %s%s\n" % ("inflating" if zi.compress_type == zipfile.ZIP_DEFLATED else "extracting",
                                              zname, qname, " [data space %d%s]" % (dspace, how) if dspace else ""))
        return True

    def c_unzip(self, a):
        if not a:
            return -1
        self.qxl.require_rw()
        try:
            zf = zipfile.ZipFile(a[0])
        except zipfile.BadZipFile:
            print("%s: not a zip file" % a[0], file=sys.stderr)
            return 0
        except OSError as e:
            print("%s: %s" % (a[0], e.strerror), file=sys.stderr)
            return 0
        with zf:
            ok = bad = 0
            for zi in zf.infolist():
                if self._zip_extract(zf, zi):
                    ok += 1
                else:
                    bad += 1
        self.out.text("%s: %d entr%s extracted\n" % (a[0], ok, "y" if ok == 1 else "ies"))
        if bad:
            print("%s: %d entr%s not extracted" % (a[0], bad, "y" if bad == 1 else "ies"), file=sys.stderr)
        return 0

    def c_mkdir(self, a):
        if not a:
            return 1
        try:
            self.qxl.mkdir(self.full(a[0]))
        except QXLError as e:
            print(e)                                  # the original prints this one to stdout
        return 0

    def c_rm(self, a):
        if not a:
            return 1
        self.qxl.remove(self.full(a[0]))
        return 0

    def c_rmdir(self, a):
        if not a:
            return 1
        self.qxl.rmdir(self.full(a[0]))
        return 0

    @staticmethod
    def unify(x, sectc):
        ts = float(x * sectc)
        if ts > 1024 * 1024:
            return ts / (1024 * 1024), "M"
        if ts > 1024:
            return ts / 1024, "K"
        return ts, " "

    def c_info(self, a):
        q = self.qxl
        ts, tsb = self.unify(q.total, q.sectc)
        fs, fsb = self.unify(q.free, q.sectc)
        o = self.out.text
        o("Info for QXL file %s %s\n" % (q.path, "" if q.rw else "(RO)"))
        o("Label %.*s" % (q.namlen, q.label))
        if len(q.label) != q.namlen:
            o(" [%s]" % q.label)
        o("\nSector size %d bytes\n" % q.sectc)
        o("Total sectors %d (%.2f %cb, on disk %d b)\n" % (q.total, ts, tsb, os.fstat(q.f.fileno()).st_size))
        o("Free  sectors %d (%.2f %cb)\n" % (q.free, fs, fsb))
        o("Formatted %d, (map len %d*512), rand %d, access %d\n" % (q.formatted, q.formatted, q.rand, q.access))
        return 0

    def c_init(self, a):
        self.qxl.init(" ".join(a)[:20])
        print("Formatting .... Done")
        self.cwd = ""
        return 0

    def c_open(self, a):
        if self.qxl is not None:
            return 1
        fn = a[0] if a else os.environ.get("QXL_FILE", DEFQXL)
        self.qxl = QXL(fn, self.rw_flag)
        self.cwd = ""
        return 0

    def c_close(self, a):
        self.qxl.close()
        self.qxl, self.cwd = None, ""
        return 0

    def _reopen(self, rw):
        path, cwd = self.qxl.path, self.cwd
        self.qxl.close()
        self.rw_flag = rw
        self.qxl = QXL(path, rw)
        self.cwd = cwd if self.qxl.find(cwd, T_DIR) else ""
        return 0

    def c_ro(self, a):
        return self._reopen(False)

    def c_rw(self, a):
        return self._reopen(True)

    def c_shell(self, a):
        cmd = " ".join(a) or os.environ.get("COMSPEC" if sys.platform == "win32" else "SHELL", "")
        if cmd:
            sys.stdout.flush()
            subprocess.call(cmd, shell=True)
        return 0

    def c_format(self, a):
        fn = size = label = None
        if len(a) >= 1:
            fn = a[0]
        if len(a) >= 2:
            size = a[1]
        if len(a) >= 3:
            label = " ".join(a[2:])
        if not label:
            try:
                fn = input("QXL File name : ")
                size = input("Size in Mb : ")
                label = input("Label  : ")
            except EOFError:
                print()
                return 0
        try:
            mb = int(size, 10)
        except (TypeError, ValueError):
            raise QXLError("Bad size: %s" % size)
        QXL.create(fn, mb, label, overwrite=bool(self.fmode))
        print("Formatting .... Done")
        return 0

    def c_clone(self, a):
        if len(a) < 2:
            return -1
        frm, to = a[0], a[1]
        if CLONE_SEP in frm:
            direction, spec, local = "I", frm, to
        elif CLONE_SEP in to:
            direction, spec, local = "O", to, frm
        else:
            print("clone needs file%sdirectory for the other QXL.WIN" % CLONE_SEP, file=sys.stderr)
            return 0
        fname, other_dir = spec.rsplit(CLONE_SEP, 1) if sys.platform == "win32" else spec.split(CLONE_SEP, 1)
        other_dir = "" if other_dir == "_" else qname(other_dir).rstrip("_")
        local = "" if local == "_" else self.full(qname(local).rstrip("_"))
        other = QXL(fname, rw=(direction == "O"))
        try:
            src, dst = (other, self.qxl) if direction == "I" else (self.qxl, other)
            s_start, d_name = (other_dir, local) if direction == "I" else (local, other_dir)
            n = clone_tree(src, s_start, dst, d_name)
            print("%d item(s) copied" % n)
        finally:
            other.close()
        return 0


def clone_tree(src, s_start, dst, d_name):
    """Copy everything below directory `s_start` of `src` into directory `d_name` of `dst`."""
    dst.require_rw()
    if s_start:
        found = src.find(s_start, T_DIR)
        if not found:
            raise QXLError("Not found %s" % s_start)
        start_dir = src.child_dir(*found)
    else:
        start_dir = src.root_dir()
    if d_name and not dst.find(d_name, T_DIR):
        dst.mkdir(d_name)
    cut = len(s_start) + 1 if s_start else 0
    n = 0
    for d, i, e in src.walk(start_dir):
        if not e.nlen or e.length < ESIZE:
            continue
        rel = e.name[cut:]
        target = (d_name + "_" + rel) if d_name else rel
        try:
            if e.is_dir:
                if not dst.find(target, T_DIR):
                    dst.mkdir(target)
            else:
                dst.put(target, src.read_file(e), e.date, e.data if e.type == 1 else 0)
            n += 1
        except QXLError as ex:
            print("%s: %s" % (e.name, ex), file=sys.stderr)
    return n


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------

USAGE = """Usage: qxltool [-W] [-w] [-h] [-c command] [QXL_FILE] [params]
If QXL_FILE is not given, the environment variable QXL_FILE is used, then
%s

qxltool opens the QXL.WIN read-only to protect your data; give -w for
read-write:                qxltool -w qxl.win

To create and format a new QXL.WIN:
                           qxltool -w file_name size_in_MB Label0 ... LabelN
e.g.                       qxltool -w qxl.win 8 QXL Disk Label
makes an 8 MB file with the label "QXL Disk Label".

To format an existing file you must give -W instead of -w.
"""


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    try:
        opts, args = getopt.gnu_getopt(argv, "wWhc:", ["help"])
    except getopt.GetoptError as e:
        print(e, file=sys.stderr)
        return 2
    rw, fmode, cmds = False, 0, []
    for o, v in opts:
        if o in ("-h", "--help"):
            sys.stderr.write(USAGE % DEFQXL)
            return 0
        elif o == "-W":
            fmode, rw = 1, True
        elif o == "-w":
            rw = True
        elif o == "-c":
            cmds.append(v)
    fn = args[0] if args else os.environ.get("QXL_FILE", DEFQXL)
    shell = Shell(None, rw, fmode)
    try:
        if len(args) > 2:                              # file size label... : format a new file
            try:
                mb = int(args[1], 10)
            except ValueError:
                raise QXLError("Bad size: %s" % args[1])
            QXL.create(fn, mb, " ".join(args[2:]), overwrite=bool(fmode))
            print("Formatting .... Done")
        shell.qxl = QXL(fn, rw)
    except QXLError as e:
        print(e, file=sys.stderr)
        sys.stderr.write(USAGE % DEFQXL)
        return 1

    tty_in, tty_out = sys.stdin.isatty(), sys.stdout.isatty()
    lines = iter(cmds) if cmds else None
    while not shell.quit:
        if lines is not None:
            line = next(lines, None)
        elif tty_in:
            try:
                line = input("> ")
            except (EOFError, KeyboardInterrupt):
                line = None
        else:
            line = sys.stdin.readline()
            line = line.rstrip("\r\n") if line else None
        if line is None:
            break
        shell.run(line)
        sys.stdout.flush()
        if lines is None and not tty_in and not tty_out:   # end-of-output marker for GUI front ends (wxqt2)
            sys.stdout.write("EOM\b\b\b\n")
            sys.stdout.flush()
    if not cmds and tty_out:
        print("quit")
    if shell.qxl:
        shell.qxl.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())