#!/usr/bin/env python3
"""
qxltool_gui.py - a simple graphical front end for qxltool.py (QXL.WIN files)

Python GUI by SM7I Projects 2026

Browse a Sinclair QL QXL.WIN file: add files, folders and zip archives, extract
them, make folders, delete, and create / re-format QXL.WIN files.

Needs only Python 3.8+ (tkinter ships with the Windows installer); keep
qxltool.py in the same folder.   Run:  python qxltool_gui.py [file.win]
GPLv3, like qxltool.  BACK UP YOUR QXL.WIN FIRST, and do not use it while
QPC / QXL has the file open.
"""

import contextlib
import io
import os
import queue
import struct
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import qxltool as qx  # noqa: E402

APP_NAME = "QXL Tool"
ESIZE, T_DIR = qx.ESIZE, qx.T_DIR


class Capture:
    """Stands in for a command's output (Shell.out) and collects the text."""
    is_file = False

    def __init__(self):
        self.buf = []

    def text(self, s):
        self.buf.append(s)

    def data(self, b):
        pass

    def close(self):
        pass

    def value(self):
        return "".join(self.buf)


def safe_host_name(name):
    """QDOS names may contain characters Windows file names cannot."""
    return "".join("_" if c in '<>:"/\\|?*' or ord(c) < 32 else c for c in name).rstrip(" .") or "_"


def shown(e, cwd):
    p = cwd + "_" if cwd else ""
    return e.name[len(p):] if p and e.name.casefold().startswith(p.casefold()) else e.name


def get_dir(q, cwd):
    found = q.find(cwd, T_DIR) if cwd else None
    return q.child_dir(*found) if found else q.root_dir()


def add_host_path(q, prefix, src, errors):
    """Copy a host file or folder (recursively) into the QXL.WIN under `prefix`."""
    name = prefix + os.path.basename(src.rstrip("/\\")).replace(".", "_")
    if os.path.isdir(src):
        if not q.find(name, T_DIR):
            try:
                q.mkdir(name)
            except qx.QXLError as e:
                errors.append(str(e))
                return
        for child in sorted(os.listdir(src)):
            add_host_path(q, name + "_", os.path.join(src, child), errors)
        return
    try:
        with open(src, "rb") as fh:
            data = fh.read()
        ds = struct.unpack(">I", data[-4:])[0] if len(data) >= 8 and data[-8:-4] == b"XTcc" else 0
        q.put(name, data, qx.file_ql_time(src), ds)
    except (OSError, qx.QXLError) as e:
        errors.append("%s: %s" % (src, getattr(e, "strerror", None) or e))


def extract_entry(q, e, rel, dest_dir, errors):
    """Extract a file or a whole folder from the QXL.WIN into the host folder dest_dir."""
    if not e.is_dir:
        _extract_file(q, e, os.path.join(dest_dir, safe_host_name(rel)), errors)
        return
    base = os.path.join(dest_dir, safe_host_name(rel))
    os.makedirs(base, exist_ok=True)
    found = q.find(e.name, T_DIR)
    if not found:
        return
    hostdir = {e.name: base}
    for d, _i, c in q.walk(q.child_dir(*found)):
        if not c.nlen or c.length < ESIZE:
            continue
        rel = c.name[len(d.name) + 1:] if d.name else c.name
        host = os.path.join(hostdir.get(d.name, base), safe_host_name(rel))
        if c.is_dir:
            os.makedirs(host, exist_ok=True)
            hostdir[c.name] = host
        else:
            _extract_file(q, c, host, errors)


def _extract_file(q, e, path, errors):
    try:
        data = q.read_file(e)
        with open(path, "wb") as fh:
            fh.write(data)
            if e.type == 1 and e.data and data[-8:-4] != b"XTcc":   # keep the data space (as cp does)
                fh.write(b"XTcc" + struct.pack(">I", e.data))
    except OSError as ex:
        errors.append("%s: %s" % (path, ex.strerror))


def delete_entry(q, name, is_dir):
    if not is_dir:
        q.remove(name)
        return
    found = q.find(name, T_DIR)
    if not found:
        raise qx.QXLError("Not found")
    todo = [(c.name, c.is_dir) for _d, _i, c in q.walk(q.child_dir(*found)) if c.nlen and c.length >= ESIZE]
    for n, d in reversed(todo):                       # children before their directories
        q.rmdir(n) if d else q.remove(n)
    q.rmdir(name)


class NewDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("New QXL.WIN")
        self.transient(parent)
        self.resizable(False, False)
        self.result = None
        f = ttk.Frame(self, padding=12)
        f.grid()
        self.v_file, self.v_size, self.v_label = tk.StringVar(), tk.StringVar(value="8"), tk.StringVar()
        ttk.Label(f, text="File:").grid(row=0, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v_file, width=34).grid(row=0, column=1, pady=2)
        ttk.Button(f, text="Browse…", command=self._browse).grid(row=0, column=2, padx=(4, 0))
        ttk.Label(f, text="Size (MB, 1-256):").grid(row=1, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v_size, width=8).grid(row=1, column=1, sticky="w", pady=2)
        ttk.Label(f, text="Label (20 chars):").grid(row=2, column=0, sticky="w")
        ttk.Entry(f, textvariable=self.v_label, width=24).grid(row=2, column=1, sticky="w", pady=2)
        b = ttk.Frame(f)
        b.grid(row=3, column=0, columnspan=3, sticky="e", pady=(10, 0))
        ttk.Button(b, text="OK", command=self._ok).pack(side="left", padx=4)
        ttk.Button(b, text="Cancel", command=self.destroy).pack(side="left")
        self.bind("<Return>", lambda e: self._ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()
        self.wait_visibility()

    def _browse(self):
        n = filedialog.asksaveasfilename(parent=self, defaultextension=".win",
                                         filetypes=[("QXL.WIN files", "*.win"), ("All files", "*.*")])
        if n:
            self.v_file.set(n)

    def _ok(self):
        try:
            mb = int(self.v_size.get())
        except ValueError:
            messagebox.showerror(APP_NAME, "Size must be a whole number of MB (1-256).", parent=self)
            return
        if not self.v_file.get().strip() or not 1 <= mb <= 256:
            messagebox.showerror(APP_NAME, "Choose a file name and a size from 1 to 256 MB.", parent=self)
            return
        self.result = (self.v_file.get().strip(), mb, self.v_label.get().strip() or "QXL")
        self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("820x500")
        self.minsize(600, 320)
        self.q = None            # the open qxltool.QXL
        self.cwd = ""            # full flat name of the current directory ("" = root)
        self.busy = False
        self.readonly = tk.BooleanVar(value=False)
        self._build_ui()
        self._update_state()

    # ------------------------------------------------------------ layout --
    def _build_ui(self):
        menubar = tk.Menu(self)
        m = tk.Menu(menubar, tearoff=False)
        m.add_command(label="Open QXL.WIN…", accelerator="Ctrl+O", command=self.cmd_open)
        m.add_command(label="New QXL.WIN…", accelerator="Ctrl+N", command=self.cmd_new)
        m.add_separator()
        m.add_checkbutton(label="Read-only mode", variable=self.readonly, command=self.cmd_toggle_ro)
        m.add_command(label="Info…", command=self.cmd_info)
        m.add_command(label="Re-format (erases everything)…", command=self.cmd_format)
        m.add_separator()
        m.add_command(label="Exit", command=self.destroy)
        menubar.add_cascade(label="QXL.WIN", menu=m)
        h = tk.Menu(menubar, tearoff=False)
        h.add_command(label="About", command=lambda: messagebox.showinfo(
            APP_NAME, "Python/Tk front end for qxltool.py\nPort of qxltool by Jonathan R. Hudson\n"
                      "(fork: github.com/xXorAa/qxltool). GPLv3.\r\n" "Python GUI by SM7I Projects 2026", parent=self))
        menubar.add_cascade(label="Help", menu=h)
        self.config(menu=menubar)
        self.menu = m

        bar = ttk.Frame(self, padding=(6, 6, 6, 2))
        bar.pack(fill="x")
        self.buttons = {}
        for key, text, cmd in (("open", "Open…", self.cmd_open), ("new", "New…", self.cmd_new),
                               ("add", "Add files…", self.cmd_add_files),
                               ("addf", "Add folder…", self.cmd_add_folder),
                               ("zip", "Unzip…", self.cmd_unzip),
                               ("get", "Extract…", self.cmd_extract),
                               ("mkdir", "New folder…", self.cmd_mkdir),
                               ("rm", "Delete", self.cmd_delete), ("refresh", "Refresh", self.refresh)):
            b = ttk.Button(bar, text=text, command=cmd)
            b.pack(side="left", padx=2)
            self.buttons[key] = b

        nav = ttk.Frame(self, padding=(6, 2))
        nav.pack(fill="x")
        self.b_up = ttk.Button(nav, text="Up", width=7, command=self.go_up)
        self.b_up.pack(side="left")
        self.v_path = tk.StringVar(value="/")
        ttk.Label(nav, textvariable=self.v_path, relief="sunken", anchor="w",
                  padding=(6, 2)).pack(side="left", fill="x", expand=True, padx=6)

        body = ttk.Frame(self, padding=(6, 2))
        body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(body, columns=("size", "date", "info"), selectmode="extended")
        for col, text, w, anchor in (("#0", "Name", 330, "w"), ("size", "Size", 90, "e"),
                                     ("date", "Date", 140, "w"), ("info", "Data space", 90, "e")):
            self.tree.heading(col, text=text, anchor=anchor)
            self.tree.column(col, width=w, anchor=anchor, stretch=(col == "#0"))
        scroll = ttk.Scrollbar(body, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="left", fill="y")
        self.tree.bind("<Double-1>", self._on_double)
        self.tree.bind("<Return>", self._on_double)
        self.tree.bind("<BackSpace>", lambda e: self.go_up())
        self.tree.bind("<Delete>", lambda e: self.cmd_delete())
        self.tree.bind("<<TreeviewSelect>>", lambda e: self._update_state())
        self.ctx = tk.Menu(self, tearoff=False)
        self.ctx.add_command(label="Extract…", command=self.cmd_extract)
        self.ctx.add_command(label="Delete", command=self.cmd_delete)
        self.tree.bind("<Button-3>", self._on_context)

        status = ttk.Frame(self, padding=(6, 2))
        status.pack(fill="x")
        self.v_status = tk.StringVar(value="No QXL.WIN open. Use Open… or New…")
        ttk.Label(status, textvariable=self.v_status).pack(side="left")
        self.progress = ttk.Progressbar(status, mode="indeterminate", length=120)
        self.bind("<Control-o>", lambda e: self.cmd_open())
        self.bind("<Control-n>", lambda e: self.cmd_new())
        self.bind("<F5>", lambda e: self.refresh())

    def _update_state(self):
        has = self.q is not None and not self.busy
        edit = has and not self.readonly.get()
        sel = bool(self.tree.selection())

        def st(key, on):
            self.buttons[key].state(["!disabled"] if on else ["disabled"])
        for key in ("add", "addf", "zip", "mkdir"):
            st(key, edit)
        st("rm", edit and sel)
        st("get", has and sel)
        st("refresh", has)
        st("open", not self.busy)
        st("new", not self.busy)
        self.b_up.state(["!disabled"] if has and self.cwd else ["disabled"])
        for label in ("Info…", "Re-format (erases everything)…"):
            self.menu.entryconfig(label, state="normal" if has else "disabled")

    # -------------------------------------------------- background worker --
    def run_bg(self, work, done=None, message="Working…"):
        if self.busy:
            return
        self.busy = True
        self.v_status.set(message)
        self.progress.pack(side="right")
        self.progress.start(12)
        self.config(cursor="watch")
        self._update_state()
        results = queue.Queue()

        def target():
            err = io.StringIO()
            try:
                with contextlib.redirect_stderr(err):
                    value = work()
                results.put((True, value, err.getvalue()))
            except qx.QXLError as e:
                results.put((False, str(e), err.getvalue()))
            except Exception as e:                    # keep the GUI alive whatever happens
                results.put((False, "%s: %s" % (type(e).__name__, e), err.getvalue()))

        threading.Thread(target=target, daemon=True).start()
        self._poll(results, done)

    def _poll(self, results, done):
        try:
            ok, value, warn = results.get_nowait()
        except queue.Empty:
            self.after(80, self._poll, results, done)
            return
        self.busy = False
        self.progress.stop()
        self.progress.pack_forget()
        self.config(cursor="")
        if not ok:
            messagebox.showerror(APP_NAME, value, parent=self)
        elif warn.strip():
            messagebox.showwarning(APP_NAME, warn.strip()[:1500], parent=self)
        if ok and done:
            done(value)
        elif self.q:
            self.refresh()
        self._update_state()

    # ----------------------------------------------------------- browsing --
    def refresh(self):
        if not self.q or self.busy:
            return
        q, cwd = self.q, self.cwd

        def work():
            rows, d = [], get_dir(q, cwd)
            for _i, e in q.list_dir(d):
                if e.nlen:
                    rows.append((e.name, shown(e, cwd), e.is_dir, e.size, e.date, e.type, e.data))
            return d.name, rows

        self.run_bg(work, self._show, "Reading…")

    def _show(self, result):
        cwd, rows = result
        self.cwd = cwd
        self.tree.delete(*self.tree.get_children())
        for full, name, is_dir, size, date, typ, ds in sorted(rows, key=lambda r: (not r[2], r[1].casefold())):
            self.tree.insert("", "end", iid=full, text=("▸ " if is_dir else "    ") + name,
                             values=("<DIR>" if is_dir else self._fmt_size(size),
                                     "" if is_dir else qx.ql_to_datetime(date).strftime("%d-%m-%y %H:%M"),
                                     str(ds) if typ == 1 else ""),
                             tags=("dir",) if is_dir else ())
        self.v_path.set(self.cwd or "/")
        q = self.q
        folders = sum(1 for r in rows if r[2])
        self.v_status.set("%d files, %d folders   |   %s   |   %.1f MB, %.1f MB free   |   %s" % (
            len(rows) - folders, folders, q.label or "(no label)", q.total * q.sectc / 1048576,
            q.free * q.sectc / 1048576, "read-only" if not q.rw else "read-write"))
        self.title("%s - %s" % (os.path.basename(q.path), APP_NAME))
        self._update_state()

    @staticmethod
    def _fmt_size(n):
        return "%d B" % n if n < 1024 else "%.1f KB" % (n / 1024) if n < 1 << 20 else "%.1f MB" % (n / (1 << 20))

    def _selected(self):
        return [(i, "dir" in self.tree.item(i, "tags")) for i in self.tree.selection()]

    def _on_double(self, _e=None):
        sel = self._selected()
        if len(sel) == 1 and sel[0][1]:
            self.cwd = sel[0][0]
            self.refresh()

    def go_up(self):
        if self.q and self.cwd:
            found = self.q.find(self.cwd, T_DIR)
            self.cwd = found[0].name if found else ""
            self.refresh()

    def _on_context(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            if row not in self.tree.selection():
                self.tree.selection_set(row)
            self.ctx.tk_popup(event.x_root, event.y_root)

    # ------------------------------------------------------------- files --
    def open_file(self, path):
        old, rw = self.q, not self.readonly.get()      # (Tk variables must be read on the main thread)

        def work():
            return qx.QXL(path, rw=rw)

        def done(q):
            if old:
                old.close()
            self.q, self.cwd = q, ""
            self.refresh()

        self.run_bg(work, done, "Opening…")

    def cmd_open(self):
        p = filedialog.askopenfilename(parent=self, filetypes=[("QXL.WIN files", "*.win"), ("All files", "*.*")])
        if p:
            self.open_file(p)

    def cmd_new(self):
        dlg = NewDialog(self)
        self.wait_window(dlg)
        if not dlg.result:
            return
        path, mb, label = dlg.result
        exists = os.path.exists(path)
        if exists and not messagebox.askyesno(APP_NAME, "%s already exists. Overwrite and format it?" % path,
                                              icon="warning", parent=self):
            return

        def work():
            qx.QXL.create(path, mb, label, overwrite=exists)
            return path

        self.run_bg(work, self.open_file, "Creating QXL.WIN…")

    def cmd_toggle_ro(self):
        if self.q:
            self.open_file(self.q.path)
        self._update_state()

    def _prefix(self):
        return self.cwd + "_" if self.cwd else ""

    def add_paths(self, paths):
        q, prefix = self.q, self._prefix()

        def work():
            errors = []
            for p in paths:
                add_host_path(q, prefix, p, errors)
            return errors

        def done(errors):
            self.refresh()
            if errors:
                messagebox.showwarning(APP_NAME, "Some items could not be added:\n\n" + "\n".join(errors[:10]),
                                       parent=self)

        self.run_bg(work, done, "Copying into QXL.WIN…")

    def cmd_add_files(self):
        p = filedialog.askopenfilenames(parent=self, title="Add files")
        if p:
            self.add_paths(list(p))

    def cmd_add_folder(self):
        p = filedialog.askdirectory(parent=self, title="Add folder")
        if p:
            self.add_paths([p])

    def cmd_unzip(self):
        p = filedialog.askopenfilename(parent=self, title="Unzip into this directory",
                                       filetypes=[("Zip archives", "*.zip"), ("All files", "*.*")])
        if not p:
            return
        q, cwd = self.q, self.cwd

        def work():
            sh = qx.Shell(q, True, 0)
            sh.cwd, sh.out = cwd, Capture()
            sh.c_unzip([p])
            return sh.out.value()

        def done(log):
            self.refresh()
            messagebox.showinfo(APP_NAME, log.strip()[-1500:] or "Nothing extracted.", parent=self)

        self.run_bg(work, done, "Unzipping…")

    def cmd_extract(self):
        sel = self._selected()
        if not sel:
            return
        dest = filedialog.askdirectory(parent=self, title="Extract to folder")
        if not dest:
            return
        q, cwd = self.q, self.cwd

        def work():
            errors = []
            for full, _is_dir in sel:
                found = q.find(full)
                if found:
                    extract_entry(q, found[2], shown(found[2], cwd), dest, errors)
            return errors

        def done(errors):
            self.v_status.set("Extracted %d item(s) to %s" % (len(sel), dest))
            if errors:
                messagebox.showwarning(APP_NAME, "\n".join(errors[:10]), parent=self)

        self.run_bg(work, done, "Extracting…")

    def cmd_mkdir(self):
        name = simpledialog.askstring(APP_NAME, "New folder name:", parent=self)
        if name and name.strip():
            q, full = self.q, self._prefix() + name.strip()
            self.run_bg(lambda: q.mkdir(full), lambda _: self.refresh(), "Creating folder…")

    def cmd_delete(self):
        sel = self._selected()
        if not sel or self.busy or self.readonly.get():
            return
        what = sel[0][0] if len(sel) == 1 else "%d items" % len(sel)
        if not messagebox.askyesno(APP_NAME, "Delete %s from the QXL.WIN?\n(Folders are deleted with all their "
                                   "contents.)" % what, icon="warning", parent=self):
            return
        q = self.q

        def work():
            for full, is_dir in sel:
                delete_entry(q, full, is_dir)

        self.run_bg(work, lambda _: self.refresh(), "Deleting…")

    def cmd_info(self):
        sh = qx.Shell(self.q, False, 0)
        sh.out = Capture()
        sh.c_info([])
        messagebox.showinfo(APP_NAME, sh.out.value(), parent=self)

    def cmd_format(self):
        if not self.q.rw:
            messagebox.showerror(APP_NAME, "The file is open read-only (see the QXL.WIN menu).", parent=self)
            return
        label = simpledialog.askstring(APP_NAME, "Re-formatting ERASES EVERYTHING in this QXL.WIN.\n\n"
                                       "New label (OK to erase, Cancel to keep):", parent=self)
        if label is None:
            return
        q = self.q

        def work():
            q.init(label.strip() or "QXL")

        def done(_):
            self.cwd = ""
            self.refresh()

        self.run_bg(work, done, "Formatting…")


def main():
    if sys.platform == "win32":
        try:                                           # crisp text on high-DPI displays
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    app = App()
    if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
        app.after(100, app.open_file, sys.argv[1])
    app.mainloop()


if __name__ == "__main__":
    main()