#!/usr/bin/env python3
"""
mdvtool_gui.py - a simple graphical front end for mdvtool.py (QLAY .mdv images)

Python GUI by SM7I Projects 2026

Open or create a microdrive image, add files or whole ZIP archives (QDOS file
headers inside the ZIP are honoured), extract files, rename or erase the
cartridge, check it, and save.  Changes are made in memory and written to disk
only when you choose Save, exactly like mdvtool's `write` command.

Needs only Python 3.8+ (tkinter ships with the Windows installer); keep
mdvtool.py in the same folder.   Run:  python mdvtool_gui.py [image.mdv]
GPL, like mdvtool.
"""

import datetime
import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, simpledialog, ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mdvtool as md  # noqa: E402

APP_NAME = "MDV Tool"


def safe_host_name(name):
    """QDOS names may contain characters Windows file names cannot."""
    return "".join("_" if c in '<>:"/\\|?*' or ord(c) < 32 else c for c in name).rstrip(" .") or "_"


def fmt_date(secs):
    """QDOS time (seconds since 1961-01-01) as text; blank when unset."""
    if not secs or secs & 0x80000000:
        return ""
    return (datetime.datetime(1961, 1, 1) + datetime.timedelta(seconds=secs)).strftime("%d-%m-%y %H:%M")


def fmt_size(n):
    return "%d B" % n if n < 1024 else "%.1f KB" % (n / 1024)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("780x470")
        self.minsize(560, 320)
        self.mdv = None
        self.path = None
        self.log = []
        self._build_ui()
        self._update_state()

    # ------------------------------------------------------------ layout --
    def _build_ui(self):
        menubar = tk.Menu(self)
        f = tk.Menu(menubar, tearoff=False)
        f.add_command(label="Open image…", accelerator="Ctrl+O", command=self.cmd_open)
        f.add_command(label="New blank image…", accelerator="Ctrl+N", command=self.cmd_new)
        f.add_separator()
        f.add_command(label="Save", accelerator="Ctrl+S", command=self.cmd_save)
        f.add_command(label="Save as…", command=self.cmd_save_as)
        f.add_separator()
        f.add_command(label="Exit", command=self.on_close)
        menubar.add_cascade(label="File", menu=f)
        i = tk.Menu(menubar, tearoff=False)
        i.add_command(label="Rename cartridge…", command=self.cmd_rename)
        i.add_command(label="Set random number (hex)…", command=self.cmd_rand)
        i.add_command(label="Check image…", command=self.cmd_check)
        i.add_separator()
        i.add_command(label="Erase all files…", command=self.cmd_erase)
        menubar.add_cascade(label="Image", menu=i)
        h = tk.Menu(menubar, tearoff=False)
        h.add_command(label="About", command=lambda: messagebox.showinfo(
            APP_NAME, "Python/Tk front end for mdvtool.py\nPort of mdvtool (Till Harbaum, Jason Lucas, "
                      "squidrpi, xXorAa)\ngithub.com/xxoraa/mdvtool\r\n" "Python GUI by SM7I Projects 2026", parent=self))
        menubar.add_cascade(label="Help", menu=h)
        self.config(menu=menubar)
        self.menus = (f, i)

        bar = ttk.Frame(self, padding=(6, 6, 6, 2))
        bar.pack(fill="x")
        self.buttons = {}
        for key, text, cmd in (("open", "Open…", self.cmd_open), ("new", "New…", self.cmd_new),
                               ("save", "Save", self.cmd_save), ("add", "Add files…", self.cmd_add_files),
                               ("zip", "Add ZIP…", self.cmd_add_zip), ("get", "Extract…", self.cmd_extract),
                               ("check", "Check…", self.cmd_check), ("erase", "Erase all…", self.cmd_erase)):
            b = ttk.Button(bar, text=text, command=cmd)
            b.pack(side="left", padx=2)
            self.buttons[key] = b

        body = ttk.Frame(self, padding=(6, 4))
        body.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(body, columns=("size", "type", "info", "date"), selectmode="extended")
        for col, text, w, anchor in (("#0", "Name", 260, "w"), ("size", "Size", 90, "e"),
                                     ("type", "Type", 70, "w"), ("info", "Data space", 90, "e"),
                                     ("date", "Updated", 140, "w")):
            self.tree.heading(col, text=text, anchor=anchor)
            self.tree.column(col, width=w, anchor=anchor, stretch=(col == "#0"))
        scroll = ttk.Scrollbar(body, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="left", fill="y")
        self.tree.bind("<<TreeviewSelect>>", lambda e: self._update_state())
        self.tree.bind("<Double-1>", lambda e: self.cmd_extract())
        self.ctx = tk.Menu(self, tearoff=False)
        self.ctx.add_command(label="Extract…", command=self.cmd_extract)
        self.tree.bind("<Button-3>", self._on_context)

        status = ttk.Frame(self, padding=(6, 2))
        status.pack(fill="x")
        self.v_status = tk.StringVar(value="No image open. Use Open… or New…")
        ttk.Label(status, textvariable=self.v_status).pack(side="left")
        self.bind("<Control-o>", lambda e: self.cmd_open())
        self.bind("<Control-n>", lambda e: self.cmd_new())
        self.bind("<Control-s>", lambda e: self.cmd_save())
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _update_state(self):
        has = self.mdv is not None
        sel = bool(self.tree.selection())

        def st(key, on):
            self.buttons[key].state(["!disabled"] if on else ["disabled"])
        for key in ("save", "add", "zip", "check", "erase"):
            st(key, has)
        st("get", has and sel)
        for menu in self.menus:
            for n in range(menu.index("end") + 1):
                if menu.type(n) == "command" and menu.entrycget(n, "label") not in (
                        "Open image…", "New blank image…", "Exit"):
                    menu.entryconfig(n, state="normal" if has else "disabled")

    def _on_context(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            if row not in self.tree.selection():
                self.tree.selection_set(row)
            self.ctx.tk_popup(event.x_root, event.y_root)

    # ----------------------------------------------------------- helpers --
    def new_mdv(self):
        self.log = []
        return md.MDV(out=self.log.append, warn=self.log.append)

    def show_log(self, title=None):
        text = "".join(self.log).strip()
        self.log = []
        if text:
            bad = any(k in text for k in ("not found", "already exists", "Image full", "ERROR", "WARNING", "Error",
                                          "Unable", "skipping"))
            (messagebox.showwarning if bad else messagebox.showinfo)(title or APP_NAME, text[-1800:], parent=self)

    def mark(self):
        name = os.path.basename(self.path) if self.path else "(new image)"
        self.title("%s%s - %s" % ("*" if self.mdv and self.mdv.modified else "", name, APP_NAME))

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        m = self.mdv
        if not m:
            self.mark()
            return
        for j, f in m.files_list():
            self.tree.insert("", "end", iid=str(j), text=f.name_str,
                             values=(fmt_size(max(0, md.s32(f.length) - 64)),
                                     ("EXEC" if f.type else "DATA") if f.type <= 1 else "????",
                                     str(md.s32(f.info0)) if f.type == 1 else "", fmt_date(f.last_update)))
        free, total = m.free_sectors(), sum(1 for x in m.sector_table if x != 255)
        self.v_status.set('Cartridge "%s"  |  random 0x%04x  |  %d files  |  %d of %d sectors free%s' % (
            m.medium_name[:10].decode("latin-1").strip(), m.hdr_rnd, len(self.tree.get_children()),
            free, total, "  |  UNSAVED CHANGES" if m.modified else ""))
        self.mark()
        self._update_state()

    def confirm_discard(self):
        if self.mdv and self.mdv.modified:
            ans = messagebox.askyesnocancel(APP_NAME, "Save changes to the current image first?", parent=self)
            if ans is None:
                return False
            if ans:
                return self.cmd_save()
        return True

    # ------------------------------------------------------------- files --
    def cmd_open(self, path=None):
        if not self.confirm_discard():
            return
        path = path or filedialog.askopenfilename(parent=self, filetypes=[("MDV images", "*.mdv"), ("All files", "*.*")])
        if not path:
            return
        m = self.new_mdv()
        try:
            m.load(path)
        except md.MDVError as e:
            messagebox.showerror(APP_NAME, str(e), parent=self)
            return
        self.mdv, self.path = m, path
        warn = [l for l in self.log if "WARNING" in l or "Rand mismatch" in l]
        self.log = []
        self.refresh()
        if warn:
            messagebox.showwarning(APP_NAME, "".join(warn)[-1500:], parent=self)

    def cmd_new(self):
        if not self.confirm_discard():
            return
        name = simpledialog.askstring(APP_NAME, "Cartridge name (up to 10 characters):", initialvalue="MD", parent=self)
        if name is None:
            return
        m = self.new_mdv()
        m.create()
        if name.strip() and name.strip() != "MD":
            m.rename(name.strip())
        self.log = []
        self.mdv, self.path = m, None
        self.refresh()

    def cmd_save_as(self):
        if not self.mdv:
            return False
        p = filedialog.asksaveasfilename(parent=self, defaultextension=".mdv",
                                         filetypes=[("MDV images", "*.mdv"), ("All files", "*.*")])
        if not p:
            return False
        self.path = p
        return self.cmd_save()

    def cmd_save(self):
        if not self.mdv:
            return False
        if not self.path:
            return self.cmd_save_as()
        try:
            self.mdv.write(self.path)
        except md.MDVError as e:
            messagebox.showerror(APP_NAME, str(e), parent=self)
            return False
        self.log = []
        self.refresh()
        return True

    def on_close(self):
        if self.confirm_discard():
            self.destroy()

    # --------------------------------------------------------- operations --
    def run_op(self, func, *args):
        try:
            func(*args)
        except md.MDVError as e:
            self.log.append(str(e) + "\n")
        self.refresh()
        self.show_log()

    def cmd_add_files(self):
        paths = filedialog.askopenfilenames(parent=self, title="Add files")
        if not paths:
            return
        for p in paths:
            try:
                self.mdv.file_import(p)
            except md.MDVError as e:
                self.log.append("%s: %s\n" % (os.path.basename(p), e))
                break
        self.refresh()
        self.show_log("Add files")

    def cmd_add_zip(self):
        p = filedialog.askopenfilename(parent=self, title="Import a ZIP archive",
                                       filetypes=[("ZIP archives", "*.zip"), ("All files", "*.*")])
        if p:
            self.run_op(self.mdv.zip_import, p)

    def cmd_extract(self):
        sel = [int(i) for i in self.tree.selection()]
        if not sel:
            return
        dest = filedialog.askdirectory(parent=self, title="Extract to folder")
        if not dest:
            return
        ok = 0
        for j in sel:
            name = self.mdv.entry(j).name_str
            if self.mdv.file_export(name, os.path.join(dest, safe_host_name(name)), xtcc=True):
                ok += 1
        self.v_status.set("Extracted %d of %d file(s) to %s" % (ok, len(sel), dest))
        if ok != len(sel):
            self.show_log("Extract")
        self.log = []

    def cmd_rename(self):
        name = simpledialog.askstring(APP_NAME, "New cartridge name (up to 10 characters):",
                                      initialvalue=self.mdv.medium_name.decode("latin-1").strip(), parent=self)
        if name is not None:
            self.mdv.rename(name)
            self.log = []
            self.refresh()

    def cmd_rand(self):
        text = simpledialog.askstring(APP_NAME, "Random number (hex, 0000-FFFF):",
                                      initialvalue="%04x" % self.mdv.hdr_rnd, parent=self)
        if text is not None:
            self.mdv.set_rand(text)
            self.log = []
            self.refresh()

    def cmd_erase(self):
        if messagebox.askyesno(APP_NAME, "Erase ALL files from this image?\n(Nothing is saved until you choose Save.)",
                               icon="warning", parent=self):
            self.mdv.erase()
            self.log = []
            self.refresh()

    def cmd_check(self):
        m = self.mdv
        buf = []
        old = m.out
        m.out = buf.append
        try:
            m.check_files()
            m.check_mapping()
            m.dir()
            m.file_chains()
        finally:
            m.out = old
        win = tk.Toplevel(self)
        win.title("Check - %s" % (os.path.basename(self.path) if self.path else "new image"))
        win.geometry("700x460")
        box = scrolledtext.ScrolledText(win, font=("Courier New" if sys.platform == "win32" else "monospace", 10))
        box.pack(fill="both", expand=True)
        box.insert("end", "".join(buf))
        box.config(state="disabled")


def main():
    if sys.platform == "win32":
        try:                                           # crisp text on high-DPI displays
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    app = App()
    if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
        app.after(100, app.cmd_open, sys.argv[1])
    app.mainloop()


if __name__ == "__main__":
    main()
