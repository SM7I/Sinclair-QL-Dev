#!/usr/bin/env python3
"""
mdvtool.py - create and edit QLAY-format microdrive images (.mdv).

A Python port of mdvtool (Till Harbaum; create/ZIP fixes by Jason Lucas and
squidrpi; XTcc import and `rand` by xXorAa): https://github.com/xxoraa/mdvtool

Python port by SM7I Projects 2026

Usage:  mdvtool.py <image.mdv> commands...
        mdvtool.py create commands...

Commands (run in the order given, and the image is only changed in memory
until you `write` it):
   create               - (as the "image" argument) start from a new blank image
   dir                  - list MDV contents
   check_files          - check file integrity
   file_chains          - list chain of sectors for each file
   check_mapping        - check the sector mapping
   show_mapping         - show physical/logical sector mapping
   export file_name     - export a file from the MDV image
   erase                - erase the MDV image
   name image_name      - rename the MDV image
   rand random          - set the rand (hex) for the MDV image
   import file_name     - import a file to the MDV image
   zip_import file_name - import an entire ZIP archive
   write file_name      - write the MDV image

Example:  mdvtool.py GamesCart.mdv erase name Gunner zip_import gunner.zip write gunner.mdv

Needs only Python 3.8+ (standard library).  GPL, like the original.

Differences from the C tool: a loaded image keeps its sector order when written
(the C tool reverses it); import uses the file's base name; ZIP directory
entries are skipped and '/' in ZIP names becomes '_'; the 68-byte "QZHD"
QDOS header in a ZIP is understood as well as the 72-byte form; the image
is checked for free space before a file is added (the C tool would crash).
"""

import os
import random
import re
import struct
import sys
import zipfile

SECTORS = 255
ENTRY = 686                       # 28 byte header + 658 byte sector
IMAGE_SIZE = SECTORS * ENTRY      # 174930
FREE_FILE = 0xFD                  # file number of a free sector
DIR_ESIZE = 64

# offsets inside one 686 byte entry
H_FF, H_SNUM, H_NAME, H_RND, H_CSUM = 12, 13, 14, 24, 26
S_BHPRE, S_FILE, S_BLOCK, S_BHCSUM, S_DPRE, S_DATA, S_DCSUM, S_EXTRA = 28, 40, 41, 42, 44, 52, 564, 566


class MDVError(Exception):
    """A fatal, user-facing error."""


def csum(b):
    return (0x0F0F + sum(b)) & 0xFFFF


def s32(v):
    """C's %d of a 32 bit value."""
    return v - (1 << 32) if v & 0x80000000 else v


class FileHdr:
    """The 64 byte QDOS file header / directory entry (all fields big-endian)."""
    FMT = struct.Struct(">IBB2IH36sIII")
    assert FMT.size == 64

    def __init__(self, length=0, access=0, type=0, info0=0, info1=0, name_len=0, name=b"",
                 last_update=0, version=0, last_backup=0):
        self.length, self.access, self.type = length, access, type
        self.info0, self.info1, self.name_len = info0, info1, name_len
        self.name, self.last_update, self.version, self.last_backup = bytes(name), last_update, version, last_backup

    @classmethod
    def unpack(cls, raw):
        return cls(*cls.FMT.unpack(bytes(raw)))

    def pack(self):
        return self.FMT.pack(self.length, self.access, self.type, self.info0, self.info1, self.name_len,
                             self.name[:36].ljust(36, b"\0"), self.last_update, self.version, self.last_backup)

    @property
    def name_str(self):
        return self.name.split(b"\0", 1)[0].decode("latin-1")

    def set_name(self, text):
        b = text.encode("latin-1", "replace")[:36]
        self.name, self.name_len = b, len(b)

    def show(self):
        """The one-line listing used by `dir` and `file_chains`."""
        kind = ("EXEC" if self.type else "DATA") if self.type <= 1 else "????"
        s = "%16s %5d %s, V:%x, U:%d, B:%d" % (self.name_str, s32(self.length), kind, self.version,
                                               s32(self.last_update), s32(self.last_backup))
        if self.type == 1:
            s += " info: %d/%d" % (s32(self.info0), s32(self.info1))
        return s + "\n"


class Slot:
    """One 686 byte entry: sector header + block header + 512 data bytes."""
    __slots__ = ("raw",)

    def __init__(self, raw=None):
        self.raw = bytearray(ENTRY if raw is None else raw)

    ff = property(lambda s: s.raw[H_FF])
    snum = property(lambda s: s.raw[H_SNUM])
    file = property(lambda s: s.raw[S_FILE])
    block = property(lambda s: s.raw[S_BLOCK])
    hdr_name = property(lambda s: bytes(s.raw[H_NAME:H_NAME + 10]))
    rnd = property(lambda s: struct.unpack_from("<H", s.raw, H_RND)[0])
    hdr_csum = property(lambda s: struct.unpack_from("<H", s.raw, H_CSUM)[0])
    bh_csum = property(lambda s: struct.unpack_from("<H", s.raw, S_BHCSUM)[0])
    data_csum = property(lambda s: struct.unpack_from("<H", s.raw, S_DCSUM)[0])
    data = property(lambda s: memoryview(s.raw)[S_DATA:S_DATA + 512])

    def set_hdr(self, name=None, rnd=None):
        if name is not None:
            self.raw[H_NAME:H_NAME + 10] = name
        if rnd is not None:
            struct.pack_into("<H", self.raw, H_RND, rnd)
        struct.pack_into("<H", self.raw, H_CSUM, csum(self.raw[H_FF:H_FF + 14]))

    def set_block(self, file, block):
        self.raw[S_FILE], self.raw[S_BLOCK] = file, block
        struct.pack_into("<H", self.raw, S_BHCSUM, csum(self.raw[S_FILE:S_FILE + 2]))

    def fix_data_csum(self):
        struct.pack_into("<H", self.raw, S_DCSUM, csum(self.raw[S_DATA:S_DATA + 512]))


class MDV:
    """An in-memory microdrive image.  Text normally printed by the C tool goes to `out`
    (stdout) and `warn` (stderr); a GUI can replace both."""

    def __init__(self, out=None, warn=None):
        self.out = out or sys.stdout.write
        self.warn = warn or (lambda s: sys.stderr.write(s))
        self.reset()

    def reset(self):
        self.buf = []
        self.order = list(range(SECTORS))      # file order, as positions in buf
        self.sector_table = [0xFF] * SECTORS   # position -> logical sector number
        self.files = [[0xFF] * 256 for _ in range(256)]
        self.medium_name = b""
        self.hdr_rnd = 0
        self.modified = False

    # ---------------------------------------------------------------- lookup --
    def get_index(self, s):
        try:
            return self.sector_table.index(s)
        except ValueError:
            return 0xFFFF

    def sector0(self):
        i = self.get_index(0)
        if i == 0xFFFF:
            raise MDVError("Sector 0 (the file map) is missing")
        return self.buf[i]

    def get_mapping_entry(self, i):
        d = self.sector0().data
        return 256 * d[2 * i] + d[2 * i + 1]

    def file_get_sector(self, file, block):
        n = self.files[file][block]
        if n == 255:
            return None
        i = self.get_index(n)
        if i == 0xFFFF:
            raise MDVError("File %d block %d points to missing sector %d" % (file, block, n))
        return self.buf[i]

    # --------------------------------------------------------- create / load --
    def create(self, rnd=None):
        self.reset()
        self.out("Creating mdv\n")
        name = b"MD        "
        rnd = random.getrandbits(16) if rnd is None else rnd
        for c in range(SECTORS):
            s = Slot()
            r = s.raw
            r[10] = r[11] = 0xFF
            r[H_FF], r[H_SNUM] = 0xFF, c
            r[S_BHPRE + 10] = r[S_BHPRE + 11] = 0xFF
            r[S_DPRE + 6] = r[S_DPRE + 7] = 0xFF
            r[S_FILE] = FREE_FILE
            r[S_EXTRA:S_EXTRA + 120] = b"\x5a" * 120
            d = s.data
            if c == 0:                                   # sector 0: the file map
                r[S_FILE] = 0x80
                for k in range(0, 512, 2):
                    d[k], d[k + 1] = 0xFD, 0x00
                d[0] = 0xF8
                d[2] = 0x00
            if c == 1:                                   # sector 1: root directory, 1 entry
                r[S_FILE] = 0x00
                d[2], d[3] = 0x00, 0x40
            s.set_hdr(name, rnd)
            struct.pack_into("<H", r, S_BHCSUM, csum(r[S_FILE:S_FILE + 2]))
            s.fix_data_csum()
            self.buf.append(s)
        self.order = [0] + list(range(SECTORS - 1, 0, -1))   # written 0, 254, 253 ... 1
        self._verify()
        self.modified = True

    def load(self, path):
        self.reset()
        self.out("Loading %s ...\n" % path)
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError:
            raise MDVError("Unable to open %s" % path)
        if len(data) != IMAGE_SIZE:
            raise MDVError("Unexpected file size (%d bytes; a QLAY image is %d)" % (len(data), IMAGE_SIZE))
        self.buf = [Slot(data[i * ENTRY:(i + 1) * ENTRY]) for i in range(SECTORS)]
        self._verify()

    @staticmethod
    def _preamble_ok(b, zeros):
        return all(x == 0 for x in b[:zeros]) and b[zeros] == 0xFF and b[zeros + 1] == 0xFF

    def _verify(self):
        free = used = 0
        for i, s in enumerate(self.buf):
            if not self._preamble_ok(s.raw, 10):
                raise MDVError("Header @%d: Preamble check failed" % i)
            if s.ff != 0xFF:
                continue                                  # unused entry
            if s.hdr_csum != csum(s.raw[H_FF:H_FF + 14]):
                raise MDVError("Header @%d: checksum failed" % i)
            if not self.medium_name or self.medium_name[0] == 0:
                self.medium_name = s.hdr_name
            elif self.medium_name != s.hdr_name:
                raise MDVError('Header @%d: Medium name mismatch ("%s" != "%s")' % (
                    i, s.hdr_name.decode("latin-1"), self.medium_name.decode("latin-1")))
            if not self.hdr_rnd:
                self.hdr_rnd = s.rnd
            elif s.rnd != self.hdr_rnd:
                self.warn("Header @%d: Rand mismatch 0x%04x:0x%04x\n" % (i, s.rnd, self.hdr_rnd))
            self.sector_table[i] = s.snum
            if not self._preamble_ok(s.raw[S_BHPRE:], 10):
                raise MDVError("Sector @%d: Block header preamble check failed" % i)
            if s.bh_csum != csum(s.raw[S_FILE:S_FILE + 2]):
                self.out("WARNING: Sector @%d(%d): Block header checksum failed\n" % (i, s.snum))
            dc = csum(s.raw[S_DATA:S_DATA + 512])
            if s.data_csum != dc:
                self.out("WARNING: Sector @%d(%d): Data checksum failed %x != %x\n" % (i, s.snum, s.data_csum, dc))
            if s.file == FREE_FILE:
                free += 1
            else:
                if self.files[s.file][s.block] != 255:
                    raise MDVError("Sector @%d: Multiple file/block %d/%d" % (i, s.file, s.block))
                used += 1
                self.files[s.file][s.block] = s.snum
        self.out('Medium name: "%s"\n' % self.medium_name[:10].decode("latin-1"))
        self.out("Rand: 0x%04x\n" % self.hdr_rnd)
        for i in range(SECTORS):                          # gaps in the sector list
            n = self.sector_table[i]
            if n != 255 and n > 0 and self.get_index(n - 1) == 0xFFFF:
                self.warn("WARNING: Missing sector %d\n" % (n - 1))
        self.out("Total sectors: %d (%d bytes)\n" % (used + free, (used + free) * 512))
        self.out("Sectors used: %d (%d bytes)\n" % (used, used * 512))
        self.out("Sectors free: %d (%d bytes)\n" % (free, free * 512))

    def write(self, path):
        self.out("Writing mdv %s\n" % path)
        try:
            with open(path, "wb") as f:
                for p in self.order:
                    s = self.buf[p]
                    if s.ff == 0xFF:
                        s.fix_data_csum()
                    f.write(s.raw)
        except OSError as e:
            raise MDVError("Error writing %s: %s" % (path, e.strerror))
        self.modified = False

    # --------------------------------------------------------- directory --
    def get_entry(self, i):
        """-> (slot, byte offset of the 64 byte entry) or None."""
        s = self.file_get_sector(0, i // 8)
        if s is None:
            self.out("Missing directory sector %d\n" % (i // 8))
            return None
        return s, DIR_ESIZE * (i & 7)

    def entry(self, i):
        e = self.get_entry(i)
        return FileHdr.unpack(e[0].data[e[1]:e[1] + DIR_ESIZE]) if e else None

    def dir_entries(self):
        """Number of 64 byte entries in the directory file (the header counts as one)."""
        e = self.entry(0)
        return max(0, s32(e.length)) // DIR_ESIZE if e else 0

    def file_open(self, name):
        n = self.dir_entries()
        if n < 2:
            return -1
        names = [(j, (self.entry(j) or FileHdr()).name_str) for j in range(1, n)]
        for j, nm in names:
            if nm == name:
                return j
        low = name.casefold()                              # QDOS names ignore case
        for j, nm in names:
            if nm.casefold() == low:
                return j
        return -1

    def files_list(self):
        """[(index, FileHdr)] of the regular files in the directory file."""
        return [(j, self.entry(j)) for j in range(1, self.dir_entries()) if self.entry(j)]

    def read_file(self, j):
        """The data of directory entry j, without its 64 byte header."""
        f = self.entry(j)
        size = s32(f.length) - 64
        out, block = bytearray(), 0
        while size > 0:
            s = self.file_get_sector(j, block)
            if s is None:
                raise MDVError("File %s is missing block %d" % (f.name_str, block))
            off = 64 if block == 0 else 0
            n = min(size, 512 - off)
            out += s.data[off:off + n]
            block += 1
            size -= n
        return bytes(out)

    def file_export(self, name, dest=None, xtcc=False):
        j = self.file_open(name)
        if j < 0:
            self.out("File %s not found\n" % name)
            return False
        f = self.entry(j)
        self.out("Exporting %d bytes to '%s' ... " % (s32(f.length) - 64, dest or name))
        try:
            data = self.read_file(j)
        except MDVError as e:
            self.out("\nERROR: %s\n" % e)
            return False
        try:
            with open(dest or name, "wb") as fh:
                fh.write(data)
                if xtcc and f.type == 1 and f.info0 and data[-8:-4] != b"XTcc":
                    fh.write(b"XTcc" + struct.pack(">I", f.info0))   # keep the data space
        except OSError:
            self.out("\nERROR: Unable to open %s for writing\n" % (dest or name))
            return False
        self.out("ok!\n")
        return True

    # ------------------------------------------------------------- listing --
    def dump_chain(self, f):
        return "".join("%s%d" % (", " if j else "", self.files[f][j]) for j in range(256)
                       if self.files[f][j] != 255) + "\n"

    def dir(self):
        n = self.dir_entries()
        if n >= 1:
            self.out("DIR listing from directory file:\n")
            for j in range(1, n):
                e = self.entry(j)
                if e:
                    self.out(e.show())
        else:
            self.out("ERROR: directory file does not exist\n")
        self.out("DIR listing from file headers:\n")
        for i in range(1, 127):
            s = self.file_get_sector(i, 0)
            if s:
                self.out(FileHdr.unpack(s.data[:64]).show())
        self.out("Special:\n")
        for i in range(128, 255):
            if self.files[i][0] != 0xFF:
                self.out("<%02x> Sectors: %s" % (i, self.dump_chain(i)))

    def file_chains(self):
        self.out("File chains:\n")
        for f in range(256):
            s = self.file_get_sector(f, 0)
            if s:
                self.out("=== file %d ===\n" % f)
                if 0 < f < 128:
                    self.out("Directory entry: " + FileHdr.unpack(s.data[:64]).show())
                self.out("Sectors: " + self.dump_chain(f))

    def check_files(self):
        used = 0
        for i in range(256):
            bused = 0
            for j in range(256):
                if self.files[i][j] != 255:
                    bused += 1
                    if j > 0 and self.files[i][j - 1] == 255:
                        self.out("File %d: Missing entry for block %d\n" % (i, j - 1))
            if bused and 0 < i < 128:
                used += 1
        self.out("Number of regular files: %d\n" % used)
        if self.files[249][0] != 0xFF:
            self.out("List of defect sectors: " + self.dump_chain(249))

    def check_mapping(self):
        for i in range(255):
            me = self.get_mapping_entry(i)
            phys = self.get_index(i)
            if me != 0xFF00:
                if phys > 255:
                    self.out("WARNING: Invalid physical entry:%d\n" % phys)
                    return
                bh = 256 * self.buf[phys].file + self.buf[phys].block
                if me != bh:
                    self.out("%3d: %04x / %04x\n" % (i, me, bh))
            elif phys != 0xFFFF:
                bh = 256 * self.buf[phys].file + self.buf[phys].block
                self.out("index = %d (%x/%x)\n" % (phys, me, bh))

    def show_mapping(self):
        self.out("File offset -> sector number\n")
        for i in range(SECTORS):
            if self.sector_table[i] != 255:
                self.out("%3d -> %3d\n" % (i, self.sector_table[i]))

    def free_sectors(self):
        return sum(1 for s in range(SECTORS) if (self.get_mapping_entry(s) & 0xFF00) == 0xFD00
                   and self.get_index(s) != 0xFFFF)

    # ------------------------------------------------------------- writing --
    def get_free_block(self, file_index, block, last_block):
        for i in range(SECTORS):
            s = (last_block - 13 - i) % SECTORS
            if (self.get_mapping_entry(s) & 0xFF00) == 0xFD00 and self.get_index(s) != 0xFFFF:
                break
        else:
            raise MDVError("Image full")
        d = self.sector0().data
        d[2 * s], d[2 * s + 1] = file_index, block
        self.files[file_index][block] = s
        return self.file_get_sector(file_index, block)

    def file_write(self, f, data):
        """Store a file (FileHdr `f` + its data bytes).  Returns True if it was written."""
        f.name = f.name.split(b"\0", 1)[0].replace(b".", b"_")
        name = f.name_str
        self.out("Writing file '%s' with %d bytes to mdv image ...\n" % (name, s32(f.length)))
        data = bytearray(data)
        # programs modified to run from floppy are changed to run from microdrive
        replaced = 0
        for i in range(max(0, s32(f.length) - 5)):
            if data[i:i + 5] == b"flp1_":
                data[i:i + 5] = b"mdv1_"
                replaced += 1
        if replaced:
            self.out("!!!!INFO: Replaced %d occurances of flp1_ by mdv1_\n" % replaced)
        f.length = (f.length + 64) & 0xFFFFFFFF
        if self.file_open(name) >= 0:
            self.out("file already exists!\n")
            return False
        entries = self.dir_entries()
        if entries > 127:
            raise MDVError("Directory full (at most 127 files)")
        # work out the sectors needed first, so a full image is not left half-written
        size, need, blk = f.length, 1 if (entries & 7) == 7 else 0, 0
        while size:
            size -= min(512 if blk else 448, size)
            need += 1
            blk += 1
        if need > self.free_sectors():
            raise MDVError("Image full (%d sectors needed, %d free)" % (need, self.free_sectors()))
        if (entries & 7) == 7:                             # extend the directory file
            sec = self.get_free_block(0, entries // 8 + 1, entries // 8)
            sec.set_block(0, entries // 8 + 1)
            entries = self.dir_entries()
        e = self.get_entry(entries)
        if not e:
            raise MDVError("ERROR: Locating new entry")
        e[0].data[e[1]:e[1] + 64] = f.pack()
        h = self.get_entry(0)                              # new directory length
        h[0].data[h[1]:h[1] + 4] = struct.pack(">I", (entries + 1) * 64)
        last_block, block, size, pos = 0, 0, f.length, 0
        while size:
            blk_size = 512 if block else 512 - 64
            blk_size = min(blk_size, size)
            sec = self.get_free_block(entries, block, last_block)
            d = sec.data
            chunk = bytes(data[pos:pos + blk_size]).ljust(blk_size, b"\0")  # (the C tool reads past the end here)
            if block == 0:
                d[0:64] = f.pack()
                d[64:64 + blk_size] = chunk
            else:
                d[0:blk_size] = chunk
            sec.set_block(entries, block)
            last_block = self.files[entries][block]
            block += 1
            size -= blk_size
            pos += blk_size
        self.modified = True
        return True

    def file_import(self, path, name=None):
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except OSError:
            self.warn("Unable to open input file %s\n" % path)
            return False
        xtcc = 0
        if len(data) >= 8 and data[-8:-4] == b"XTcc":
            xtcc = struct.unpack(">I", data[-4:])[0]
        if xtcc:
            self.out("XTcc detected 0x%x\n" % xtcc)
        f = FileHdr(length=len(data))
        if xtcc:
            f.type, f.info0 = 1, xtcc
        f.set_name(name or os.path.basename(path.replace("\\", "/")))
        return self.file_write(f, data)

    def zip_import(self, path):
        self.out("Importing from ZIP %s\n" % path)
        try:
            zf = zipfile.ZipFile(path)
        except (OSError, zipfile.BadZipFile):
            self.warn("Error opening zip file %s\n" % path)
            return
        with zf:
            infos = zf.infolist()
            self.out("ZIP contains %d files\n" % len(infos))
            for zi in infos:
                if zi.filename.endswith("/"):
                    continue                               # a directory entry
                qdos = self._qdos_extra(zi.extra)
                if qdos:
                    self.out(qdos.show())
                    if zi.file_size != qdos.length:
                        self.out("WARNING: qdos/zip file size mismatch\n")
                else:
                    qdos = FileHdr(length=zi.file_size)
                    qdos.set_name(zi.filename.replace("/", "_").replace("\\", "_"))
                try:
                    data = zf.read(zi)
                except (zipfile.BadZipFile, RuntimeError, OSError, EOFError):
                    data = b""
                if len(data) < qdos.length:
                    self.warn("Error unzipping file %s, skipping it\n" % zi.filename)
                    continue
                self.file_write(qdos, data[:qdos.length])

    def _qdos_extra(self, extra):
        while len(extra) >= 4:
            zid, sz = struct.unpack_from("<HH", extra)
            blk = extra[4:4 + sz]
            if sz > len(extra) - 4:
                break
            if zid == 0xFB4A:
                if sz == 72:
                    return FileHdr.unpack(blk[8:72])
                if sz == 68 and blk[:4] == b"QZHD":
                    return FileHdr.unpack(blk[4:68])
                self.warn("Warning extra entry size mismatch, ignoring it\n")
            extra = extra[4 + sz:]
        return None

    # ----------------------------------------------------------- other ops --
    def erase(self):
        self.out("Erasing MDV image ...\n")
        d = self.sector0().data
        for i in range(SECTORS):
            file, block = d[2 * i], d[2 * i + 1]
            sec = self.file_get_sector(file, block)
            if sec:
                if file:
                    self.out("erasing file %d, block %d\n" % (file, block))
                    self.files[file][block] = 0xFF
                    d[2 * i], d[2 * i + 1] = 0xFD, 0
                    sec.set_block(0xFD, 0)
                else:
                    sec.data[:] = bytes(512)               # keep the directory sectors, but empty them
        h = self.get_entry(0)
        h[0].data[h[1]:h[1] + 4] = struct.pack(">I", 64)
        self.modified = True

    def rename(self, name):
        lname = name.encode("latin-1", "replace")[:10].ljust(10, b" ")
        self.out("Setting name: '%s'\n" % lname.decode("latin-1"))
        self.medium_name = lname
        rnd = self.hdr_rnd = random.getrandbits(16)
        for s in self.buf:
            if s.ff == 0xFF:
                s.set_hdr(lname, rnd)
        self.modified = True

    def set_rand(self, text):
        m = re.match(r"\s*[+-]?(?:0[xX])?([0-9a-fA-F]+)", text)
        rnd = (int(m.group(1), 16) if m else 0) & 0xFFFF
        self.out("Setting rand: %04x\n" % rnd)
        self.hdr_rnd = rnd
        for s in self.buf:
            if s.ff == 0xFF:
                s.set_hdr(rnd=rnd)
        self.modified = True


USAGE = """Usage: mdvtool <mdv> commands
   or: mdvtool create commands
Commands:
   create               - create a new MDV image
   dir                  - list MDV contents
   check_files          - check file integrity
   file_chains          - list chain of sectors for each file
   check_mapping        - check the sector mapping
   show_mapping         - show physical/loginal sector mapping
   export file_name     - export a file from the MDV image
   erase                - erase the MDV image
   name image_name      - rename the MDV image
   rand random          - set the rand for MDV image
   import file_name     - import a file to the MDV image
   zip_import file_name - import an entire ZIP archive
   write file_name      - write the MDV image
"""


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) < 2:
        sys.stdout.write(USAGE)
        return 0
    mdv = MDV()
    try:
        if argv[0].lower() == "create":
            mdv.create()
        else:
            mdv.load(argv[0])
    except MDVError as e:
        print(e, file=sys.stderr)
        return 1
    needs_arg = {"export", "import", "name", "rand", "zip_import", "write"}
    simple = {"dir": mdv.dir, "check_files": mdv.check_files, "erase": mdv.erase,
              "file_chains": mdv.file_chains, "check_mapping": mdv.check_mapping,
              "show_mapping": mdv.show_mapping}
    withargs = {"export": mdv.file_export, "import": mdv.file_import, "name": mdv.rename,
                "rand": mdv.set_rand, "zip_import": mdv.zip_import, "write": mdv.write}
    i = 1
    try:
        while i < len(argv):
            sys.stdout.write("\n")
            cmd = argv[i].lower()
            if cmd in needs_arg:
                i += 1
                if i >= len(argv):
                    msg = {"export": "export needs a file name as parameter",
                           "import": "import needs a file name as parameter",
                           "name": "name needs an image name as parameter",
                           "rand": "rand needs an image rand as parameter",
                           "zip_import": "zip_import needs a file name as parameter",
                           "write": "write needs a file name as parameter"}[cmd]
                    print(msg)
                    return 0
                withargs[cmd](argv[i])
            elif cmd in simple:
                simple[cmd]()
            else:
                print("Unknown command %s" % argv[i])
            i += 1
    except MDVError as e:
        sys.stdout.flush()
        print(e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
